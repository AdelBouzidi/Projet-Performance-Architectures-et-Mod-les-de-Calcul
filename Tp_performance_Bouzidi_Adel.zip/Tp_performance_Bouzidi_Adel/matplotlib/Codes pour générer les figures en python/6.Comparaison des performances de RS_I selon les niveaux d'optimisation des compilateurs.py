import numpy as np
import matplotlib.pyplot as plt

# Données
options = ['O0', 'O1', 'O2', 'O3', 'Ofast']

gcc_time = [14.228, 13.756, 12.800, 13.244, 11.297]
clang_time = [13.336, 13.423, 13.218, 13.444, 10.593]
icx_time = [4.797, 9.413, 4.762, 5.376, 5.466]

# Paramètres du graphique
x = np.arange(len(options))  # Position des groupes sur l'axe x
width = 0.25  # Largeur des barres

# Création de la figure
plt.figure(figsize=(10, 6))

# Ajouter les barres pour chaque série
plt.bar(x - width, gcc_time, width, label='GCC', color='blue', edgecolor='black')
plt.bar(x, clang_time, width, label='Clang', color='green', edgecolor='black')
plt.bar(x + width, icx_time, width, label='ICX', color='red', edgecolor='black')

# Ajouter les étiquettes et le titre
plt.xlabel('Niveaux d\'optimisation', fontsize=12)
plt.ylabel('Temps d\'exécution (secondes)', fontsize=12)
plt.title('Comparaison des performances de RS_I selon les niveaux d\'optimisation des compilateurs', fontsize=14)
plt.xticks(x, options, rotation=0, fontsize=10)
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.legend(fontsize=10)

# Afficher le graphique
plt.tight_layout()
#plt.show()
plt.savefig("fig6.png")
