import numpy as np
import matplotlib.pyplot as plt

# Données
techniques = ['RS', 'RS_AV', 'RS_B', 'RS_ESE', 'RS_I', 'RS_IM', 'RS_LFi', 'RS_LFu', 
              'RS_LI', 'RS_LU', 'RS_P', 'RS_PE', 'RS_RB', 'RS_SK']

gcc_time = [28.639, 24.325, 29.946, 14.310, 13.756, 13.870, 29.072, 28.404,
            29.730, 28.951, 14.217, 16.265, 29.355, 36.297]
clang_time = [28.607, 25.014, 28.601, 13.619, 13.423, 13.305, 28.381, 29.701, 
              29.882, 28.665, 14.256, 14.316, 28.680, 37.495]
icx_time = [9.342, 9.226, 9.503, 9.487, 9.413, 9.189, 9.126, 9.120, 9.072, 
            8.768, 9.202, 8.386, 9.214, 8.703]

# Paramètres du graphique
x = np.arange(len(techniques))  # Position des groupes sur l'axe x
width = 0.25  # Largeur des barres

# Création de la figure
plt.figure(figsize=(14, 8))

# Ajouter les barres pour chaque série
plt.bar(x - width, gcc_time, width, label='GCC', color='blue')
plt.bar(x, clang_time, width, label='Clang', color='green')
plt.bar(x + width, icx_time, width, label='ICX', color='red')

# Ajouter les étiquettes et le titre
plt.xlabel('Techniques optimisation O1', fontsize=12)
plt.ylabel('Temps d\'exécution (secondes)', fontsize=12)
plt.title('Comparaison des temps d\'exécution des techniques d\'optimisation selon les compilateurs avec le niveau O1', fontsize=16)
plt.xticks(x, techniques, rotation=45, ha='right')
plt.grid()           
plt.legend()

# Afficher le graphique
plt.tight_layout()
#plt.show()
plt.savefig("fig2.png")
