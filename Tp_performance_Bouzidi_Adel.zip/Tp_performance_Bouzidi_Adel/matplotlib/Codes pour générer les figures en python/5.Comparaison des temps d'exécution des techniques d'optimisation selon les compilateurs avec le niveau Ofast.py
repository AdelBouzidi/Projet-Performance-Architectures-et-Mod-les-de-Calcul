import numpy as np
import matplotlib.pyplot as plt

# Données
techniques = ['RS', 'RS_AV', 'RS_B', 'RS_ESE', 'RS_I', 'RS_IM', 'RS_LFi', 'RS_LFu', 
              'RS_LI', 'RS_LU', 'RS_P', 'RS_PE', 'RS_RB', 'RS_SK']

gcc_time = [11.061, 11.847, 11.582, 11.501, 11.297, 11.413, 11.775, 
            12.180, 11.578, 9.588, 11.860, 8.659, 11.638, 11.529]
clang_time = [11.281, 10.967, 10.628, 11.606, 10.593, 10.825, 11.346, 
              14.108, 11.235, 10.710, 11.290, 14.430, 11.919, 11.614]
icx_time = [6.284, 5.895, 6.265, 6.311, 5.466, 5.607, 5.846, 10.764, 
            5.878, 5.828, 5.568, 8.063, 5.750, 5.602]

# Paramètres du graphique
x = np.arange(len(techniques))  # Position des groupes sur l'axe x
width = 0.25  # Largeur des barres

# Création de la figure
plt.figure(figsize=(14, 8))

# Ajouter les barres pour chaque série
plt.bar(x - width, gcc_time, width, label='GCC', color='blue')
plt.bar(x, clang_time, width, label='Clang', color='green')
plt.bar(x + width, icx_time, width, label='ICX', color='red')

# Ajouter les étiquettes et le titre
plt.xlabel('Techniques optimisation fast', fontsize=12)
plt.ylabel('Temps d\'exécution (secondes)', fontsize=12)
plt.title('Comparaison des temps d\'exécution des techniques d\'optimisation selon les compilateurs avec le niveau Ofast', fontsize=16)
plt.xticks(x, techniques, rotation=45, ha='right')
plt.grid()           
plt.legend()

# Afficher le graphique
plt.tight_layout()
#plt.show()
plt.savefig("fig5.png")
