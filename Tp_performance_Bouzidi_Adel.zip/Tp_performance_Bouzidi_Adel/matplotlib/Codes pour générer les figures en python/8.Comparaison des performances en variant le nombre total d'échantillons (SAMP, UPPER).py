import matplotlib.pyplot as plt

# Données
X = [10000, 20000, 30000, 40000, 50000, 60000, 70000, 80000, 90000, 100000]

gcc_time_samp_10  = [0.102, 0.272, 0.499, 0.753, 1.062, 1.436, 1.863, 2.159, 2.539, 2.964]
gcc_time_samp_50  = [0.448, 1.234, 2.265, 3.497, 5.664, 8.679, 11.630, 12.462, 11.541, 13.539]
gcc_time_samp_100 = [0.868, 2.419, 4.376, 7.264, 10.664, 12.267, 15.447, 18.828, 22.522, 26.347]
gcc_nbr = [10142, 22489, 35659, 49369, 63475, 77901, 92596, 107516, 122638, 137931]

clang_time_samp_10  = [0.108, 0.302, 0.550, 0.890, 1.268, 1.712, 2.221, 2.806, 3.396, 4.857]
clang_time_samp_50  = [0.377, 1.089, 2.061, 3.328, 5.131, 9.066, 11.464, 10.671, 12.934, 15.587]
clang_time_samp_100 = [0.726, 2.046, 3.758, 6.019, 8.565, 11.695, 15.270, 19.109, 24.386, 29.300]
clang_nbr = [10142, 22489, 35659, 49369, 63475, 77901, 92596, 107516, 122638, 137931]

icx_time_samp_10  = [0.050, 0.118, 0.211, 0.316, 0.454, 0.578, 0.722, 0.868, 1.051, 1.200]
icx_time_samp_50  = [0.223, 0.578, 1.094, 1.604, 2.197, 2.878, 3.502, 4.249, 5.070, 5.875]
icx_time_samp_100 = [0.452, 1.176, 2.166, 3.196, 5.776, 8.016, 10.114, 11.629, 13.070, 14.038]
icx_nbr = [10142, 22489, 35659, 49369, 63475, 77901, 92596, 107516, 122638, 137931]

# Création des subplots
fig, axs = plt.subplots(3, 2, figsize=(14, 10), constrained_layout=True)

# Graphiques pour GCC
axs[0, 0].plot(X, gcc_nbr, label="GCC Nombres", color="blue", marker="o")
axs[0, 0].set_title("GCC - Nombre de Zéros Trouvés")
axs[0, 0].set_xlabel("UPPER")
axs[0, 0].set_ylabel("Nombre de Zéros")
axs[0, 0].grid()

axs[0, 1].plot(X, gcc_time_samp_10, label="Samp = 10", color="blue", marker="o")
axs[0, 1].plot(X, gcc_time_samp_50, label="Samp = 50", color="green", marker="s")
axs[0, 1].plot(X, gcc_time_samp_100, label="Samp = 100", color="red", marker="^")
axs[0, 1].set_title("GCC - Temps d'exécution")
axs[0, 1].set_xlabel("UPPER")
axs[0, 1].set_ylabel("Temps (secondes)")
axs[0, 1].legend()
axs[0, 1].grid()

# Graphiques pour Clang
axs[1, 0].plot(X, clang_nbr, label="Clang Nombres", color="blue", marker="o")
axs[1, 0].set_title("Clang - Nombre de Zéros Trouvés")
axs[1, 0].set_xlabel("UPPER")
axs[1, 0].set_ylabel("Nombre de Zéros")
axs[1, 0].grid()

axs[1, 1].plot(X, clang_time_samp_10, label="Samp = 10", color="blue", marker="o")
axs[1, 1].plot(X, clang_time_samp_50, label="Samp = 50", color="green", marker="s")
axs[1, 1].plot(X, clang_time_samp_100, label="Samp = 100", color="red", marker="^")
axs[1, 1].set_title("Clang - Temps d'exécution")
axs[1, 1].set_xlabel("UPPER")
axs[1, 1].set_ylabel("Temps (secondes)")
axs[1, 1].legend()
axs[1, 1].grid()

# Graphiques pour ICX
axs[2, 0].plot(X, icx_nbr, label="ICX Nombres", color="blue", marker="o")
axs[2, 0].set_title("ICX - Nombre de Zéros Trouvés")
axs[2, 0].set_xlabel("UPPER")
axs[2, 0].set_ylabel("Nombre de Zéros")
axs[2, 0].grid()

axs[2, 1].plot(X, icx_time_samp_10, label="Samp = 10", color="blue", marker="o")
axs[2, 1].plot(X, icx_time_samp_50, label="Samp = 50", color="green", marker="s")
axs[2, 1].plot(X, icx_time_samp_100, label="Samp = 100", color="red", marker="^")
axs[2, 1].set_title("ICX - Temps d'exécution")
axs[2, 1].set_xlabel("UPPER")
axs[2, 1].set_ylabel("Temps (secondes)")
axs[2, 1].legend()
axs[2, 1].grid()

# Affichage
plt.suptitle("Comparaison des performances en variant le nombre total d'échantillons (SAMP, UPPER)", fontsize=16)
#plt.show()
plt.savefig("fig8.png")
