import numpy as np
import matplotlib.pyplot as plt

# Données
techniques = ['RS', 'RS_AV', 'RS_B', 'RS_ESE', 'RS_I', 'RS_IM', 'RS_LFi', 'RS_LFu', 
              'RS_LI', 'RS_LU', 'RS_P', 'RS_PE', 'RS_RB', 'RS_SK']

gcc_time = [29.107, 24.429, 28.226, 13.557, 13.244, 14.309, 32.631, 
            31.289, 31.385, 28.168, 13.781, 14.010, 27.772, 44.242]
clang_time = [36.449, 31.230, 35.001, 14.905, 13.444, 16.484, 37.961, 
              40.001, 37.265, 31.758, 15.021, 15.550, 29.970, 38.276]
icx_time = [5.446, 5.563, 5.865, 5.868, 5.376, 5.270, 5.832, 10.697, 
            5.770, 5.739, 5.538, 8.021, 5.892, 5.511]

# Paramètres du graphique
x = np.arange(len(techniques))  # Position des groupes sur l'axe x
width = 0.25  # Largeur des barres

# Création de la figure
plt.figure(figsize=(14, 8))

# Ajouter les barres pour chaque série
plt.bar(x - width, gcc_time, width, label='GCC', color='blue')
plt.bar(x, clang_time, width, label='Clang', color='green')
plt.bar(x + width, icx_time, width, label='ICX', color='red')

# Ajouter les étiquettes et le titre
plt.xlabel('Techniques optimisation O3', fontsize=12)
plt.ylabel('Temps d\'exécution (secondes)', fontsize=12)
plt.title('Comparaison des temps d\'exécution des techniques d\'optimisation selon les compilateurs avec le niveau O3', fontsize=16)
plt.xticks(x, techniques, rotation=45, ha='right')
plt.grid()           
plt.legend()

# Afficher le graphique
plt.tight_layout()
#plt.show()
plt.savefig("fig4.png")
