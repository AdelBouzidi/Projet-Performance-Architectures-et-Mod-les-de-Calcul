import numpy as np
import matplotlib.pyplot as plt

# Données
techniques = ['RS', 'RS_AV', 'RS_B', 'RS_ESE', 'RS_I', 'RS_IM', 'RS_LFi', 'RS_LFu', 
              'RS_LI', 'RS_LU', 'RS_P', 'RS_PE', 'RS_RB', 'RS_SK']

gcc_time = [29.274, 24.492, 27.923, 13.590, 12.800, 12.876, 28.795, 30.016, 
            30.147, 29.032, 14.187, 14.019, 29.292, 38.263]
clang_time = [29.127, 24.865, 28.757, 13.788, 13.218, 13.000, 29.191, 29.665, 
              32.094, 31.660, 15.295, 14.711, 31.809, 39.968]
icx_time = [4.680, 4.728, 4.911, 4.893, 4.762, 4.762, 4.738, 9.401, 4.732, 
            4.787, 4.637, 6.795, 4.715, 4.481]

# Paramètres du graphique
x = np.arange(len(techniques))  # Position des groupes sur l'axe x
width = 0.25  # Largeur des barres

# Création de la figure
plt.figure(figsize=(14, 8))

# Ajouter les barres pour chaque série
plt.bar(x - width, gcc_time, width, label='GCC', color='blue')
plt.bar(x, clang_time, width, label='Clang', color='green')
plt.bar(x + width, icx_time, width, label='ICX', color='red')

# Ajouter les étiquettes et le titre
plt.xlabel('Techniques optimisation O2', fontsize=12)
plt.ylabel('Temps d\'exécution (secondes)', fontsize=12)
plt.title('Comparaison des temps d\'exécution des techniques d\'optimisation selon les compilateurs avec le niveau O2', fontsize=16)
plt.xticks(x, techniques, rotation=45, ha='right')
plt.grid()           
plt.legend()

# Afficher le graphique
plt.tight_layout()
#plt.show()
plt.savefig("fig3.png")
