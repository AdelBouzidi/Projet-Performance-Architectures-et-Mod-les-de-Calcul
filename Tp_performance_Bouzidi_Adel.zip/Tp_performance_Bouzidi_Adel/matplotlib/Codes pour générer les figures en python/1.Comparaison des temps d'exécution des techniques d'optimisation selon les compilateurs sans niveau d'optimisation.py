import numpy as np
import matplotlib.pyplot as plt

# Données
techniques = ['RS', 'RS_AV', 'RS_B', 'RS_ESE', 'RS_I', 'RS_IM', 'RS_LFi', 'RS_LFu', 
              'RS_LI', 'RS_LU', 'RS_P', 'RS_PE', 'RS_RB', 'RS_SK']

gcc_time = [26.171, 23.318, 26.783, 15.889, 14.228, 14.373, 26.267, 26.119, 26.732, 
            25.577, 15.907, 18.786, 26.393, 33.487]
clang_time = [28.677, 23.062, 29.575, 14.600, 13.336, 13.343, 25.952, 25.715, 29.632, 
              24.790, 14.866, 17.651, 25.437, 35.267]
icx_time = [4.748, 4.756, 4.918, 4.867, 4.797, 4.778, 4.765, 8.970, 4.752, 4.786, 
            4.634, 7.016, 4.753, 4.549]

# Paramètres du graphique
x = np.arange(len(techniques))  # Position des groupes sur l'axe x
width = 0.25  # Largeur des barres

# Création de la figure
plt.figure(figsize=(14, 8))

# Ajouter les barres pour chaque série
plt.bar(x - width, gcc_time, width, label='GCC', color='blue')
plt.bar(x, clang_time, width, label='Clang', color='green')
plt.bar(x + width, icx_time, width, label='ICX', color='red')

# Ajouter les étiquettes et le titre
plt.xlabel('Techniques optimisation ', fontsize=12)
plt.ylabel('Temps d\'exécution (secondes)', fontsize=12)
plt.title('Comparaison des temps d\'exécution des techniques d\'optimisation selon les compilateurs sans niveau d\'optimisation', fontsize=16)
plt.xticks(x, techniques, rotation=45, ha='right')
plt.grid()           
plt.legend()

# Afficher le graphique
plt.tight_layout()
#plt.show()
plt.savefig("fig1.png")
