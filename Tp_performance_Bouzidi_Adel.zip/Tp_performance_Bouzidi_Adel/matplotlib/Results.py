
================================> 

gcc
lower = 10
upper = 50000
samp = 100
nbr_zeros = 63517.827

techniques = [RS, RS_AV, RS_B, RS_ESE, RS_I, RS_IM, RS_LFi, RS_LFu, RS_LI, RS_LU, RS_P, RS_PE, RS_RB, RS_SK]
rs_time = [26.171, 23.318, 26.783, 15.889, 14.228, 14.373, 26.267, 26.119, 26.732, 25.577, 15.907, 18.786, 26.393, 33.487]

================================> 
clang
lower = 10
upper = 50000
samp = 100
nbr_zeros = 63517.827

techniques = [RS, RS_AV, RS_B, RS_ESE, RS_I, RS_IM, RS_LFi, RS_LFu, RS_LI, RS_LU, RS_P, RS_PE, RS_RB, RS_SK]
rs_time = [28.677, 23.062, 29.575, 14.600, 13.336, 13.343, 25.952, 25.715, 29.632, 24.790, 14.866, 17.651, 25.437, 35.267]


================================> 
icx
lower = 10
upper = 50000
samp = 100
nbr_zeros = 63517.827

techniques = [RS, RS_AV, RS_B, RS_ESE, RS_I, RS_IM, RS_LFi, RS_LFu, RS_LI, RS_LU, RS_P, RS_PE, RS_RB, RS_SK]
rs_time = [4.748, 4.756, 4.918, 4.867, 4.797, 4.778, 4.765, 8.970, 4.752, 4.786, 4.634, 7.016, 4.753, 4.549]



techniques = [RS, RS_AV, RS_B, RS_ESE, RS_I, RS_IM, RS_LFi, RS_LFu, RS_LI, RS_LU, RS_P, RS_PE, RS_RB, RS_SK]

gcc_time = [26.171, 23.318, 26.783, 15.889, 14.228, 14.373, 26.267, 26.119, 26.732, 25.577, 15.907, 18.786, 26.393, 33.487]
clang_time = [28.677, 23.062, 29.575, 14.600, 13.336, 13.343, 25.952, 25.715, 29.632, 24.790, 14.866, 17.651, 25.437, 35.267]
icx_time = [4.748, 4.756, 4.918, 4.867, 4.797, 4.778, 4.765, 8.970, 4.752, 4.786, 4.634, 7.016, 4.753, 4.549]



-------------------------------------------------------------------------------------------------------

=======================> GCC


g++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel.cpp                                       -o /root/tp_performance/optimisation/gcc/o1/RiemannSiegel
g++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel_Autovectorisation.cpp                     -o /root/tp_performance/optimisation/gcc/o1/RiemannSiegel_Autovectorisation
g++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel_Blocking.cpp                              -o /root/tp_performance/optimisation/gcc/o1/RiemannSiegel_Blocking
g++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel_Elimination_sous_expressions_communes.cpp -o /root/tp_performance/optimisation/gcc/o1/RiemannSiegel_Elimination_sous_expressions_communes
g++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel_Inlining.cpp                              -o /root/tp_performance/optimisation/gcc/o1/RiemannSiegel_Inlining
g++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel_Inlining_manuel.cpp                       -o /root/tp_performance/optimisation/gcc/o1/RiemannSiegel_Inlining_manuel
g++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Fission.cpp                          -o /root/tp_performance/optimisation/gcc/o1/RiemannSiegel_Loop_Fission
g++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Fusion.cpp                           -o /root/tp_performance/optimisation/gcc/o1/RiemannSiegel_Loop_Fusion
g++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Interchange.cpp                      -o /root/tp_performance/optimisation/gcc/o1/RiemannSiegel_Loop_Interchange
g++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Unrolling.cpp                        -o /root/tp_performance/optimisation/gcc/o1/RiemannSiegel_Loop_Unrolling
g++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel_Precomputation.cpp                        -o /root/tp_performance/optimisation/gcc/o1/RiemannSiegel_Precomputation
g++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel_Prefetching_explicite.cpp                 -o /root/tp_performance/optimisation/gcc/o1/RiemannSiegel_Prefetching_explicite
g++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel_Reduction_de_branches.cpp                 -o /root/tp_performance/optimisation/gcc/o1/RiemannSiegel_Reduction_de_branches
g++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel_Skewing.cpp                               -o /root/tp_performance/optimisation/gcc/o1/RiemannSiegel_Skewing


g++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel.cpp                                       -o /root/tp_performance/optimisation/gcc/o2/RiemannSiegel
g++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel_Autovectorisation.cpp                     -o /root/tp_performance/optimisation/gcc/o2/RiemannSiegel_Autovectorisation
g++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel_Blocking.cpp                              -o /root/tp_performance/optimisation/gcc/o2/RiemannSiegel_Blocking
g++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel_Elimination_sous_expressions_communes.cpp -o /root/tp_performance/optimisation/gcc/o2/RiemannSiegel_Elimination_sous_expressions_communes
g++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel_Inlining.cpp                              -o /root/tp_performance/optimisation/gcc/o2/RiemannSiegel_Inlining
g++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel_Inlining_manuel.cpp                       -o /root/tp_performance/optimisation/gcc/o2/RiemannSiegel_Inlining_manuel
g++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Fission.cpp                          -o /root/tp_performance/optimisation/gcc/o2/RiemannSiegel_Loop_Fission
g++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Fusion.cpp                           -o /root/tp_performance/optimisation/gcc/o2/RiemannSiegel_Loop_Fusion
g++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Interchange.cpp                      -o /root/tp_performance/optimisation/gcc/o2/RiemannSiegel_Loop_Interchange
g++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Unrolling.cpp                        -o /root/tp_performance/optimisation/gcc/o2/RiemannSiegel_Loop_Unrolling
g++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel_Precomputation.cpp                        -o /root/tp_performance/optimisation/gcc/o2/RiemannSiegel_Precomputation
g++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel_Prefetching_explicite.cpp                 -o /root/tp_performance/optimisation/gcc/o2/RiemannSiegel_Prefetching_explicite
g++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel_Reduction_de_branches.cpp                 -o /root/tp_performance/optimisation/gcc/o2/RiemannSiegel_Reduction_de_branches
g++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel_Skewing.cpp                               -o /root/tp_performance/optimisation/gcc/o2/RiemannSiegel_Skewing


g++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel.cpp                                       -o /root/tp_performance/optimisation/gcc/o3/RiemannSiegel
g++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel_Autovectorisation.cpp                     -o /root/tp_performance/optimisation/gcc/o3/RiemannSiegel_Autovectorisation
g++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel_Blocking.cpp                              -o /root/tp_performance/optimisation/gcc/o3/RiemannSiegel_Blocking
g++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel_Elimination_sous_expressions_communes.cpp -o /root/tp_performance/optimisation/gcc/o3/RiemannSiegel_Elimination_sous_expressions_communes
g++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel_Inlining.cpp                              -o /root/tp_performance/optimisation/gcc/o3/RiemannSiegel_Inlining
g++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel_Inlining_manuel.cpp                       -o /root/tp_performance/optimisation/gcc/o3/RiemannSiegel_Inlining_manuel
g++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Fission.cpp                          -o /root/tp_performance/optimisation/gcc/o3/RiemannSiegel_Loop_Fission
g++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Fusion.cpp                           -o /root/tp_performance/optimisation/gcc/o3/RiemannSiegel_Loop_Fusion
g++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Interchange.cpp                      -o /root/tp_performance/optimisation/gcc/o3/RiemannSiegel_Loop_Interchange
g++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Unrolling.cpp                        -o /root/tp_performance/optimisation/gcc/o3/RiemannSiegel_Loop_Unrolling
g++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel_Precomputation.cpp                        -o /root/tp_performance/optimisation/gcc/o3/RiemannSiegel_Precomputation
g++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel_Prefetching_explicite.cpp                 -o /root/tp_performance/optimisation/gcc/o3/RiemannSiegel_Prefetching_explicite
g++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel_Reduction_de_branches.cpp                 -o /root/tp_performance/optimisation/gcc/o3/RiemannSiegel_Reduction_de_branches
g++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel_Skewing.cpp                               -o /root/tp_performance/optimisation/gcc/o3/RiemannSiegel_Skewing


g++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel.cpp                                       -o /root/tp_performance/optimisation/gcc/fast/RiemannSiegel
g++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel_Autovectorisation.cpp                     -o /root/tp_performance/optimisation/gcc/fast/RiemannSiegel_Autovectorisation
g++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel_Blocking.cpp                              -o /root/tp_performance/optimisation/gcc/fast/RiemannSiegel_Blocking
g++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel_Elimination_sous_expressions_communes.cpp -o /root/tp_performance/optimisation/gcc/fast/RiemannSiegel_Elimination_sous_expressions_communes
g++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel_Inlining.cpp                              -o /root/tp_performance/optimisation/gcc/fast/RiemannSiegel_Inlining
g++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel_Inlining_manuel.cpp                       -o /root/tp_performance/optimisation/gcc/fast/RiemannSiegel_Inlining_manuel
g++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Fission.cpp                          -o /root/tp_performance/optimisation/gcc/fast/RiemannSiegel_Loop_Fission
g++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Fusion.cpp                           -o /root/tp_performance/optimisation/gcc/fast/RiemannSiegel_Loop_Fusion
g++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Interchange.cpp                      -o /root/tp_performance/optimisation/gcc/fast/RiemannSiegel_Loop_Interchange
g++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Unrolling.cpp                        -o /root/tp_performance/optimisation/gcc/fast/RiemannSiegel_Loop_Unrolling
g++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel_Precomputation.cpp                        -o /root/tp_performance/optimisation/gcc/fast/RiemannSiegel_Precomputation
g++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel_Prefetching_explicite.cpp                 -o /root/tp_performance/optimisation/gcc/fast/RiemannSiegel_Prefetching_explicite
g++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel_Reduction_de_branches.cpp                 -o /root/tp_performance/optimisation/gcc/fast/RiemannSiegel_Reduction_de_branches
g++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel_Skewing.cpp                               -o /root/tp_performance/optimisation/gcc/fast/RiemannSiegel_Skewing


=======================> CLANG


clang++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel.cpp                                       -o /root/tp_performance/optimisation/clang/o1/RiemannSiegel
clang++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel_Autovectorisation.cpp                     -o /root/tp_performance/optimisation/clang/o1/RiemannSiegel_Autovectorisation
clang++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel_Blocking.cpp                              -o /root/tp_performance/optimisation/clang/o1/RiemannSiegel_Blocking
clang++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel_Elimination_sous_expressions_communes.cpp -o /root/tp_performance/optimisation/clang/o1/RiemannSiegel_Elimination_sous_expressions_communes
clang++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel_Inlining.cpp                              -o /root/tp_performance/optimisation/clang/o1/RiemannSiegel_Inlining
clang++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel_Inlining_manuel.cpp                       -o /root/tp_performance/optimisation/clang/o1/RiemannSiegel_Inlining_manuel
clang++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Fission.cpp                          -o /root/tp_performance/optimisation/clang/o1/RiemannSiegel_Loop_Fission
clang++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Fusion.cpp                           -o /root/tp_performance/optimisation/clang/o1/RiemannSiegel_Loop_Fusion
clang++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Interchange.cpp                      -o /root/tp_performance/optimisation/clang/o1/RiemannSiegel_Loop_Interchange
clang++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Unrolling.cpp                        -o /root/tp_performance/optimisation/clang/o1/RiemannSiegel_Loop_Unrolling
clang++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel_Precomputation.cpp                        -o /root/tp_performance/optimisation/clang/o1/RiemannSiegel_Precomputation
clang++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel_Prefetching_explicite.cpp                 -o /root/tp_performance/optimisation/clang/o1/RiemannSiegel_Prefetching_explicite
clang++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel_Reduction_de_branches.cpp                 -o /root/tp_performance/optimisation/clang/o1/RiemannSiegel_Reduction_de_branches
clang++ -O1 /root/tp_performance/optimisation/programs/RiemannSiegel_Skewing.cpp                               -o /root/tp_performance/optimisation/clang/o1/RiemannSiegel_Skewing


clang++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel.cpp                                       -o /root/tp_performance/optimisation/clang/o2/RiemannSiegel
clang++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel_Autovectorisation.cpp                     -o /root/tp_performance/optimisation/clang/o2/RiemannSiegel_Autovectorisation
clang++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel_Blocking.cpp                              -o /root/tp_performance/optimisation/clang/o2/RiemannSiegel_Blocking
clang++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel_Elimination_sous_expressions_communes.cpp -o /root/tp_performance/optimisation/clang/o2/RiemannSiegel_Elimination_sous_expressions_communes
clang++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel_Inlining.cpp                              -o /root/tp_performance/optimisation/clang/o2/RiemannSiegel_Inlining
clang++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel_Inlining_manuel.cpp                       -o /root/tp_performance/optimisation/clang/o2/RiemannSiegel_Inlining_manuel
clang++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Fission.cpp                          -o /root/tp_performance/optimisation/clang/o2/RiemannSiegel_Loop_Fission
clang++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Fusion.cpp                           -o /root/tp_performance/optimisation/clang/o2/RiemannSiegel_Loop_Fusion
clang++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Interchange.cpp                      -o /root/tp_performance/optimisation/clang/o2/RiemannSiegel_Loop_Interchange
clang++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Unrolling.cpp                        -o /root/tp_performance/optimisation/clang/o2/RiemannSiegel_Loop_Unrolling
clang++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel_Precomputation.cpp                        -o /root/tp_performance/optimisation/clang/o2/RiemannSiegel_Precomputation
clang++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel_Prefetching_explicite.cpp                 -o /root/tp_performance/optimisation/clang/o2/RiemannSiegel_Prefetching_explicite
clang++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel_Reduction_de_branches.cpp                 -o /root/tp_performance/optimisation/clang/o2/RiemannSiegel_Reduction_de_branches
clang++ -O2 /root/tp_performance/optimisation/programs/RiemannSiegel_Skewing.cpp                               -o /root/tp_performance/optimisation/clang/o2/RiemannSiegel_Skewing


clang++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel.cpp                                       -o /root/tp_performance/optimisation/clang/o3/RiemannSiegel
clang++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel_Autovectorisation.cpp                     -o /root/tp_performance/optimisation/clang/o3/RiemannSiegel_Autovectorisation
clang++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel_Blocking.cpp                              -o /root/tp_performance/optimisation/clang/o3/RiemannSiegel_Blocking
clang++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel_Elimination_sous_expressions_communes.cpp -o /root/tp_performance/optimisation/clang/o3/RiemannSiegel_Elimination_sous_expressions_communes
clang++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel_Inlining.cpp                              -o /root/tp_performance/optimisation/clang/o3/RiemannSiegel_Inlining
clang++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel_Inlining_manuel.cpp                       -o /root/tp_performance/optimisation/clang/o3/RiemannSiegel_Inlining_manuel
clang++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Fission.cpp                          -o /root/tp_performance/optimisation/clang/o3/RiemannSiegel_Loop_Fission
clang++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Fusion.cpp                           -o /root/tp_performance/optimisation/clang/o3/RiemannSiegel_Loop_Fusion
clang++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Interchange.cpp                      -o /root/tp_performance/optimisation/clang/o3/RiemannSiegel_Loop_Interchange
clang++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Unrolling.cpp                        -o /root/tp_performance/optimisation/clang/o3/RiemannSiegel_Loop_Unrolling
clang++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel_Precomputation.cpp                        -o /root/tp_performance/optimisation/clang/o3/RiemannSiegel_Precomputation
clang++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel_Prefetching_explicite.cpp                 -o /root/tp_performance/optimisation/clang/o3/RiemannSiegel_Prefetching_explicite
clang++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel_Reduction_de_branches.cpp                 -o /root/tp_performance/optimisation/clang/o3/RiemannSiegel_Reduction_de_branches
clang++ -O3 /root/tp_performance/optimisation/programs/RiemannSiegel_Skewing.cpp                               -o /root/tp_performance/optimisation/clang/o3/RiemannSiegel_Skewing


clang++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel.cpp                                       -o /root/tp_performance/optimisation/clang/fast/RiemannSiegel
clang++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel_Autovectorisation.cpp                     -o /root/tp_performance/optimisation/clang/fast/RiemannSiegel_Autovectorisation
clang++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel_Blocking.cpp                              -o /root/tp_performance/optimisation/clang/fast/RiemannSiegel_Blocking
clang++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel_Elimination_sous_expressions_communes.cpp -o /root/tp_performance/optimisation/clang/fast/RiemannSiegel_Elimination_sous_expressions_communes
clang++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel_Inlining.cpp                              -o /root/tp_performance/optimisation/clang/fast/RiemannSiegel_Inlining
clang++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel_Inlining_manuel.cpp                       -o /root/tp_performance/optimisation/clang/fast/RiemannSiegel_Inlining_manuel
clang++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Fission.cpp                          -o /root/tp_performance/optimisation/clang/fast/RiemannSiegel_Loop_Fission
clang++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Fusion.cpp                           -o /root/tp_performance/optimisation/clang/fast/RiemannSiegel_Loop_Fusion
clang++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Interchange.cpp                      -o /root/tp_performance/optimisation/clang/fast/RiemannSiegel_Loop_Interchange
clang++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Unrolling.cpp                        -o /root/tp_performance/optimisation/clang/fast/RiemannSiegel_Loop_Unrolling
clang++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel_Precomputation.cpp                        -o /root/tp_performance/optimisation/clang/fast/RiemannSiegel_Precomputation
clang++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel_Prefetching_explicite.cpp                 -o /root/tp_performance/optimisation/clang/fast/RiemannSiegel_Prefetching_explicite
clang++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel_Reduction_de_branches.cpp                 -o /root/tp_performance/optimisation/clang/fast/RiemannSiegel_Reduction_de_branches
clang++ -Ofast /root/tp_performance/optimisation/programs/RiemannSiegel_Skewing.cpp                               -o /root/tp_performance/optimisation/clang/fast/RiemannSiegel_Skewing


=======================> ICX


icx -O1 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel.cpp                                       -o /root/tp_performance/optimisation/icx/o1/RiemannSiegel
icx -O1 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Autovectorisation.cpp                     -o /root/tp_performance/optimisation/icx/o1/RiemannSiegel_Autovectorisation
icx -O1 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Blocking.cpp                              -o /root/tp_performance/optimisation/icx/o1/RiemannSiegel_Blocking
icx -O1 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Elimination_sous_expressions_communes.cpp -o /root/tp_performance/optimisation/icx/o1/RiemannSiegel_Elimination_sous_expressions_communes
icx -O1 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Inlining.cpp                              -o /root/tp_performance/optimisation/icx/o1/RiemannSiegel_Inlining
icx -O1 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Inlining_manuel.cpp                       -o /root/tp_performance/optimisation/icx/o1/RiemannSiegel_Inlining_manuel
icx -O1 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Fission.cpp                          -o /root/tp_performance/optimisation/icx/o1/RiemannSiegel_Loop_Fission
icx -O1 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Fusion.cpp                           -o /root/tp_performance/optimisation/icx/o1/RiemannSiegel_Loop_Fusion
icx -O1 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Interchange.cpp                      -o /root/tp_performance/optimisation/icx/o1/RiemannSiegel_Loop_Interchange
icx -O1 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Unrolling.cpp                        -o /root/tp_performance/optimisation/icx/o1/RiemannSiegel_Loop_Unrolling
icx -O1 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Precomputation.cpp                        -o /root/tp_performance/optimisation/icx/o1/RiemannSiegel_Precomputation
icx -O1 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Prefetching_explicite.cpp                 -o /root/tp_performance/optimisation/icx/o1/RiemannSiegel_Prefetching_explicite
icx -O1 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Reduction_de_branches.cpp                 -o /root/tp_performance/optimisation/icx/o1/RiemannSiegel_Reduction_de_branches
icx -O1 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Skewing.cpp                               -o /root/tp_performance/optimisation/icx/o1/RiemannSiegel_Skewing


icx -O2 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel.cpp                                       -o /root/tp_performance/optimisation/icx/o2/RiemannSiegel
icx -O2 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Autovectorisation.cpp                     -o /root/tp_performance/optimisation/icx/o2/RiemannSiegel_Autovectorisation
icx -O2 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Blocking.cpp                              -o /root/tp_performance/optimisation/icx/o2/RiemannSiegel_Blocking
icx -O2 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Elimination_sous_expressions_communes.cpp -o /root/tp_performance/optimisation/icx/o2/RiemannSiegel_Elimination_sous_expressions_communes
icx -O2 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Inlining.cpp                              -o /root/tp_performance/optimisation/icx/o2/RiemannSiegel_Inlining
icx -O2 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Inlining_manuel.cpp                       -o /root/tp_performance/optimisation/icx/o2/RiemannSiegel_Inlining_manuel
icx -O2 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Fission.cpp                          -o /root/tp_performance/optimisation/icx/o2/RiemannSiegel_Loop_Fission
icx -O2 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Fusion.cpp                           -o /root/tp_performance/optimisation/icx/o2/RiemannSiegel_Loop_Fusion
icx -O2 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Interchange.cpp                      -o /root/tp_performance/optimisation/icx/o2/RiemannSiegel_Loop_Interchange
icx -O2 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Unrolling.cpp                        -o /root/tp_performance/optimisation/icx/o2/RiemannSiegel_Loop_Unrolling
icx -O2 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Precomputation.cpp                        -o /root/tp_performance/optimisation/icx/o2/RiemannSiegel_Precomputation
icx -O2 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Prefetching_explicite.cpp                 -o /root/tp_performance/optimisation/icx/o2/RiemannSiegel_Prefetching_explicite
icx -O2 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Reduction_de_branches.cpp                 -o /root/tp_performance/optimisation/icx/o2/RiemannSiegel_Reduction_de_branches
icx -O2 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Skewing.cpp                               -o /root/tp_performance/optimisation/icx/o2/RiemannSiegel_Skewing


icx -O3 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel.cpp                                       -o /root/tp_performance/optimisation/icx/o3/RiemannSiegel
icx -O3 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Autovectorisation.cpp                     -o /root/tp_performance/optimisation/icx/o3/RiemannSiegel_Autovectorisation
icx -O3 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Blocking.cpp                              -o /root/tp_performance/optimisation/icx/o3/RiemannSiegel_Blocking
icx -O3 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Elimination_sous_expressions_communes.cpp -o /root/tp_performance/optimisation/icx/o3/RiemannSiegel_Elimination_sous_expressions_communes
icx -O3 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Inlining.cpp                              -o /root/tp_performance/optimisation/icx/o3/RiemannSiegel_Inlining
icx -O3 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Inlining_manuel.cpp                       -o /root/tp_performance/optimisation/icx/o3/RiemannSiegel_Inlining_manuel
icx -O3 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Fission.cpp                          -o /root/tp_performance/optimisation/icx/o3/RiemannSiegel_Loop_Fission
icx -O3 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Fusion.cpp                           -o /root/tp_performance/optimisation/icx/o3/RiemannSiegel_Loop_Fusion
icx -O3 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Interchange.cpp                      -o /root/tp_performance/optimisation/icx/o3/RiemannSiegel_Loop_Interchange
icx -O3 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Unrolling.cpp                        -o /root/tp_performance/optimisation/icx/o3/RiemannSiegel_Loop_Unrolling
icx -O3 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Precomputation.cpp                        -o /root/tp_performance/optimisation/icx/o3/RiemannSiegel_Precomputation
icx -O3 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Prefetching_explicite.cpp                 -o /root/tp_performance/optimisation/icx/o3/RiemannSiegel_Prefetching_explicite
icx -O3 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Reduction_de_branches.cpp                 -o /root/tp_performance/optimisation/icx/o3/RiemannSiegel_Reduction_de_branches
icx -O3 -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Skewing.cpp                               -o /root/tp_performance/optimisation/icx/o3/RiemannSiegel_Skewing


icx -Ofast -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel.cpp                                       -o /root/tp_performance/optimisation/icx/fast/RiemannSiegel
icx -Ofast -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Autovectorisation.cpp                     -o /root/tp_performance/optimisation/icx/fast/RiemannSiegel_Autovectorisation
icx -Ofast -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Blocking.cpp                              -o /root/tp_performance/optimisation/icx/fast/RiemannSiegel_Blocking
icx -Ofast -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Elimination_sous_expressions_communes.cpp -o /root/tp_performance/optimisation/icx/fast/RiemannSiegel_Elimination_sous_expressions_communes
icx -Ofast -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Inlining.cpp                              -o /root/tp_performance/optimisation/icx/fast/RiemannSiegel_Inlining
icx -Ofast -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Inlining_manuel.cpp                       -o /root/tp_performance/optimisation/icx/fast/RiemannSiegel_Inlining_manuel
icx -Ofast -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Fission.cpp                          -o /root/tp_performance/optimisation/icx/fast/RiemannSiegel_Loop_Fission
icx -Ofast -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Fusion.cpp                           -o /root/tp_performance/optimisation/icx/fast/RiemannSiegel_Loop_Fusion
icx -Ofast -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Interchange.cpp                      -o /root/tp_performance/optimisation/icx/fast/RiemannSiegel_Loop_Interchange
icx -Ofast -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Loop_Unrolling.cpp                        -o /root/tp_performance/optimisation/icx/fast/RiemannSiegel_Loop_Unrolling
icx -Ofast -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Precomputation.cpp                        -o /root/tp_performance/optimisation/icx/fast/RiemannSiegel_Precomputation
icx -Ofast -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Prefetching_explicite.cpp                 -o /root/tp_performance/optimisation/icx/fast/RiemannSiegel_Prefetching_explicite
icx -Ofast -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Reduction_de_branches.cpp                 -o /root/tp_performance/optimisation/icx/fast/RiemannSiegel_Reduction_de_branches
icx -Ofast -lstdc++ /root/tp_performance/optimisation/programs/RiemannSiegel_Skewing.cpp                               -o /root/tp_performance/optimisation/icx/fast/RiemannSiegel_Skewing




./RiemannSiegel 10 50000 100
./RiemannSiegel_Autovectorisation 10 50000 100
./RiemannSiegel_Blocking 10 50000 100
./RiemannSiegel_Elimination_sous_expressions_communes 10 50000 100
./RiemannSiegel_Inlining 10 50000 100
./RiemannSiegel_Inlining_manuel 10 50000 100
./RiemannSiegel_Loop_Fission 10 50000 100
./RiemannSiegel_Loop_Fusion 10 50000 100
./RiemannSiegel_Loop_Interchange 10 50000 100
./RiemannSiegel_Loop_Unrolling 10 50000 100
./RiemannSiegel_Precomputation 10 50000 100
./RiemannSiegel_Prefetching_explicite 10 50000 100
./RiemannSiegel_Reduction_de_branches 10 50000 100
./RiemannSiegel_Skewing 10 50000 100


RiemannSiegel (RS sans optimisation), RiemannSiegel_Autovectorisation (RS_AV), RiemannSiegel_Blocking (RS_B), RiemannSiegel_Elimination_sous_expressions_communes (RS_ESE), 
RiemannSiegel_Inlining (RS_I), RiemannSiegel_Inlining_manuel (RS_IM), RiemannSiegel_Loop_Fission (RS_LFi), RiemannSiegel_Loop_Fusion (RS_LFu), 
RiemannSiegel_Loop_Interchange (RS_LI), RiemannSiegel_Loop_Unrolling (RS_LU), RiemannSiegel_Precomputation (RS_P), RiemannSiegel_Prefetching_explicite (RS_PE), 
RiemannSiegel_Reduction_de_branches (RS_RB), RiemannSiegel_Skewing (RS_SK)


================================================================================================================================ 

gcc -O1
lower = 10
upper = 50000
samp = 100
nbr_zeros = 63517.827

techniques = [RS, RS_AV, RS_B, RS_ESE, RS_I, RS_IM, RS_LFi, RS_LFu, RS_LI, RS_LU, RS_P, RS_PE, RS_RB, RS_SK]
gcc_time = [28.639, 24.325, 29.946, 14.310, 13.756, 13.870, 29.072, 28.404, 29.730, 28.951, 14.217, 16.265, 29.355, 36.297]


================================> 
clang -O1
lower = 10
upper = 50000
samp = 100
nbr_zeros = 63517.827

techniques = [RS, RS_AV, RS_B, RS_ESE, RS_I, RS_IM, RS_LFi, RS_LFu, RS_LI, RS_LU, RS_P, RS_PE, RS_RB, RS_SK]
clang_time = [28.607, 25.014, 28.601, 13.619, 13.423, 13.305, 28.381, 29.701, 29.882, 28.665, 14.256, 14.316, 28.680, 37.495]



================================> 
icx -O1
lower = 10
upper = 50000
samp = 100
nbr_zeros = 63517.827

techniques = [RS, RS_AV, RS_B, RS_ESE, RS_I, RS_IM, RS_LFi, RS_LFu, RS_LI, RS_LU, RS_P, RS_PE, RS_RB, RS_SK]
icx_time = [9.342, 9.226, 9.503, 9.487, 9.413, 9.189, 9.126, 9.120, 9.072, 8.768, 9.202, 8.386, 9.214, 8.703]





techniques = [RS, RS_AV, RS_B, RS_ESE, RS_I, RS_IM, RS_LFi, RS_LFu, RS_LI, RS_LU, RS_P, RS_PE, RS_RB, RS_SK]

gcc_time = [28.639, 24.325, 29.946, 14.310, 13.756, 13.870, 29.072, 28.404, 29.730, 28.951, 14.217, 16.265, 29.355, 36.297]
clang_time = [28.607, 25.014, 28.601, 13.619, 13.423, 13.305, 28.381, 29.701, 29.882, 28.665, 14.256, 14.316, 28.680, 37.495]
icx_time = [9.342, 9.226, 9.503, 9.487, 9.413, 9.189, 9.126, 9.120, 9.072, 8.768, 9.202, 8.386, 9.214, 8.703]



./RiemannSiegel 10 50000 100
./RiemannSiegel_Autovectorisation 10 50000 100
./RiemannSiegel_Blocking 10 50000 100
./RiemannSiegel_Elimination_sous_expressions_communes 10 50000 100
./RiemannSiegel_Inlining 10 50000 100
./RiemannSiegel_Inlining_manuel 10 50000 100
./RiemannSiegel_Loop_Fission 10 50000 100
./RiemannSiegel_Loop_Fusion 10 50000 100
./RiemannSiegel_Loop_Interchange 10 50000 100
./RiemannSiegel_Loop_Unrolling 10 50000 100
./RiemannSiegel_Precomputation 10 50000 100
./RiemannSiegel_Prefetching_explicite 10 50000 100
./RiemannSiegel_Reduction_de_branches 10 50000 100
./RiemannSiegel_Skewing 10 50000 100

================================================================================================================================

gcc -O2
lower = 10
upper = 50000
samp = 100
nbr_zeros = 63517.827

techniques = [RS, RS_AV, RS_B, RS_ESE, RS_I, RS_IM, RS_LFi, RS_LFu, RS_LI, RS_LU, RS_P, RS_PE, RS_RB, RS_SK]
gcc_time = [29.274, 24.492, 27.923, 13.590, 12.800, 12.876, 28.795, 30.016, 30.147, 29.032, 14.187, 14.019, 29.292, 38.263]



================================> 
clang -O2
lower = 10
upper = 50000
samp = 100
nbr_zeros = 63517.827

techniques = [RS, RS_AV, RS_B, RS_ESE, RS_I, RS_IM, RS_LFi, RS_LFu, RS_LI, RS_LU, RS_P, RS_PE, RS_RB, RS_SK]
clang_time = [29.127, 24.865, 28.757, 13.788, 13.218, 13.000, 29.191, 29.665, 32.094, 31.660, 15.295, 14.711, 31.809, 39.968]



================================> 
icx -O2
lower = 10
upper = 50000
samp = 100
nbr_zeros = 63517.827

techniques = [RS, RS_AV, RS_B, RS_ESE, RS_I, RS_IM, RS_LFi, RS_LFu, RS_LI, RS_LU, RS_P, RS_PE, RS_RB, RS_SK]
icx_time = [4.680, 4.728, 4.911, 4.893, 4.762, 4.762, 4.738, 9.401, 4.732, 4.787, 4.637, 6.795, 4.715, 4.481]



techniques = [RS, RS_AV, RS_B, RS_ESE, RS_I, RS_IM, RS_LFi, RS_LFu, RS_LI, RS_LU, RS_P, RS_PE, RS_RB, RS_SK]

gcc_time = [29.274, 24.492, 27.923, 13.590, 12.800, 12.876, 28.795, 30.016, 30.147, 29.032, 14.187, 14.019, 29.292, 38.263]
clang_time = [29.127, 24.865, 28.757, 13.788, 13.218, 13.000, 29.191, 29.665, 32.094, 31.660, 15.295, 14.711, 31.809, 39.968]
icx_time = [4.680, 4.728, 4.911, 4.893, 4.762, 4.762, 4.738, 9.401, 4.732, 4.787, 4.637, 6.795, 4.715, 4.481]



./RiemannSiegel 10 50000 100
./RiemannSiegel_Autovectorisation 10 50000 100
./RiemannSiegel_Blocking 10 50000 100
./RiemannSiegel_Elimination_sous_expressions_communes 10 50000 100
./RiemannSiegel_Inlining 10 50000 100
./RiemannSiegel_Inlining_manuel 10 50000 100
./RiemannSiegel_Loop_Fission 10 50000 100
./RiemannSiegel_Loop_Fusion 10 50000 100
./RiemannSiegel_Loop_Interchange 10 50000 100
./RiemannSiegel_Loop_Unrolling 10 50000 100
./RiemannSiegel_Precomputation 10 50000 100
./RiemannSiegel_Prefetching_explicite 10 50000 100
./RiemannSiegel_Reduction_de_branches 10 50000 100
./RiemannSiegel_Skewing 10 50000 100
================================================================================================================================

gcc -O3
lower = 10
upper = 50000
samp = 100
nbr_zeros = 63517.827

techniques = [RS, RS_AV, RS_B, RS_ESE, RS_I, RS_IM, RS_LFi, RS_LFu, RS_LI, RS_LU, RS_P, RS_PE, RS_RB, RS_SK]
gcc_time = [29.107, 24.429, 28.226, 13.557, 13.244, 14.309, 32.631, 31.289, 31.385, 28.168, 13.781, 14.010, 27.772, 44.242]



================================> 
clang -O3
lower = 10
upper = 50000
samp = 100
nbr_zeros = 63517.827

techniques = [RS, RS_AV, RS_B, RS_ESE, RS_I, RS_IM, RS_LFi, RS_LFu, RS_LI, RS_LU, RS_P, RS_PE, RS_RB, RS_SK]
clang_time = [36.449, 31.230, 35.001, 14.905, 13.444, 16.484, 37.961, 40.001, 37.265, 31.758, 15.021, 15.550, 29.970, 38.276]



================================> 
icx -O3
lower = 10
upper = 50000
samp = 100
nbr_zeros = 63517.827

techniques = [RS, RS_AV, RS_B, RS_ESE, RS_I, RS_IM, RS_LFi, RS_LFu, RS_LI, RS_LU, RS_P, RS_PE, RS_RB, RS_SK]
icx_time = [5.446, 5.563, 5.865, 5.868, 5.376, 5.270, 5.832, 10.697, 5.770, 5.739, 5.538, 8.021, 5.892, 5.511]



techniques = [RS, RS_AV, RS_B, RS_ESE, RS_I, RS_IM, RS_LFi, RS_LFu, RS_LI, RS_LU, RS_P, RS_PE, RS_RB, RS_SK]

gcc_time = [29.107, 24.429, 28.226, 13.557, 13.244, 14.309, 32.631, 31.289, 31.385, 28.168, 13.781, 14.010, 27.772, 44.242]
clang_time = [36.449, 31.230, 35.001, 14.905, 13.444, 16.484, 37.961, 40.001, 37.265, 31.758, 15.021, 15.550, 29.970, 38.276]
icx_time = [5.446, 5.563, 5.865, 5.868, 5.376, 5.270, 5.832, 10.697, 5.770, 5.739, 5.538, 8.021, 5.892, 5.511]


./RiemannSiegel 10 50000 100
./RiemannSiegel_Autovectorisation 10 50000 100
./RiemannSiegel_Blocking 10 50000 100
./RiemannSiegel_Elimination_sous_expressions_communes 10 50000 100
./RiemannSiegel_Inlining 10 50000 100
./RiemannSiegel_Inlining_manuel 10 50000 100
./RiemannSiegel_Loop_Fission 10 50000 100
./RiemannSiegel_Loop_Fusion 10 50000 100
./RiemannSiegel_Loop_Interchange 10 50000 100
./RiemannSiegel_Loop_Unrolling 10 50000 100
./RiemannSiegel_Precomputation 10 50000 100
./RiemannSiegel_Prefetching_explicite 10 50000 100
./RiemannSiegel_Reduction_de_branches 10 50000 100
./RiemannSiegel_Skewing 10 50000 100
================================================================================================================================

gcc -fast
lower = 10
upper = 50000
samp = 100
nbr_zeros = 63517.827

techniques = [RS, RS_AV, RS_B, RS_ESE, RS_I, RS_IM, RS_LFi, RS_LFu, RS_LI, RS_LU, RS_P, RS_PE, RS_RB, RS_SK]
gcc_time = [11.061, 11.847, 11.582, 11.501, 11.297, 11.413, 11.775, 12.180, 11.578, 9.588, 11.860, 8.659, 11.638, 11.529]



================================> 
clang -fast
lower = 10
upper = 50000
samp = 100
nbr_zeros = 63517.827

techniques = [RS, RS_AV, RS_B, RS_ESE, RS_I, RS_IM, RS_LFi, RS_LFu, RS_LI, RS_LU, RS_P, RS_PE, RS_RB, RS_SK]
clang_time = [11.281, 10.967, 10.628, 11.606, 10.593, 10.825, 11.346, 14.108, 11.235, 10.710, 11.290, 14.430, 11.919, 11.614]


================================> 
icx -fast
lower = 10
upper = 50000
samp = 100
nbr_zeros = 63517.827

techniques = [RS, RS_AV, RS_B, RS_ESE, RS_I, RS_IM, RS_LFi, RS_LFu, RS_LI, RS_LU, RS_P, RS_PE, RS_RB, RS_SK]
icx_time = [6.284, 5.895, 6.265, 6.311, 5.466, 5.607, 5.846, 10.764, 5.878, 5.828, 5.568, 8.063, 5.750, 5.602]



techniques = [RS, RS_AV, RS_B, RS_ESE, RS_I, RS_IM, RS_LFi, RS_LFu, RS_LI, RS_LU, RS_P, RS_PE, RS_RB, RS_SK]

gcc_time = [11.061, 11.847, 11.582, 11.501, 11.297, 11.413, 11.775, 12.180, 11.578, 9.588, 11.860, 8.659, 11.638, 11.529]
clang_time = [11.281, 10.967, 10.628, 11.606, 10.593, 10.825, 11.346, 14.108, 11.235, 10.710, 11.290, 14.430, 11.919, 11.614]
icx_time = [6.284, 5.895, 6.265, 6.311, 5.466, 5.607, 5.846, 10.764, 5.878, 5.828, 5.568, 8.063, 5.750, 5.602]

================================================================================================================================


technique = RS_I

techniques = [SO, O1, O2, O3, fast]

gcc_time = [14.228, 13.756, 12.800, 13.244, 11.297]
clang_time = [13.336, 13.423, 13.218, 13.444, 10.593]
icx_time = [4.797, 9.413, 4.762, 5.376, 5.466]

================================================================================================================================

technique = RS_ESE

option = [SO, O1, O2, O3, fast]

gcc_time = [15.889, 14.310, 13.590, 13.557, 11.501]
clang_time = [14.600, 13.619, 13.788, 14.905, 11.606]
icx_time = [4.867, 9.487, 4.893, 5.868, 6.311]

================================================================================================================================

g++     -Ofast          /root/tp_performance/optimisation/programs_old/RiemannSiegel_Inlining.cpp -o /root/tp_performance/optimisation/programs_old/rs_i/RiemannSiegel_Inlining_gcc
clang++ -Ofast          /root/tp_performance/optimisation/programs_old/RiemannSiegel_Inlining.cpp -o /root/tp_performance/optimisation/programs_old/rs_i/RiemannSiegel_Inlining_clang
icx     -Ofast -lstdc++ /root/tp_performance/optimisation/programs_old/RiemannSiegel_Inlining.cpp -o /root/tp_performance/optimisation/programs_old/rs_i/RiemannSiegel_Inlining_icx


UPPER = [10000, 20000, 30000, 40000, 50000, 60000, 70000, 80000, 90000, 100000]

================================> 

SAMP = 10
gcc_time_rs_i = [0.102, 0.272, 0.499, 0.753, 1.062, 1.436, 1.863, 2.159, 2.539, 2.964]
gcc_nbr_rs_i = [10142, 22489, 35659, 49369, 63475, 77901, 92596, 107516, 122638, 137931]

clang_time_rs_i = [0.108, 0.302, 0.550, 0.890, 1.268, 1.712, 2.221, 2.806, 3.396, 4.857]
clang_nbr_rs_i = [10142, 22489, 35659, 49369, 63475, 77901, 92596, 107516, 122638, 137931]

icx_time_rs_i = [0.050, 0.118, 0.211, 0.316, 0.454, 0.578, 0.722, 0.868, 1.051, 1.200]
icx_nbr_rs_i = [10142, 22489, 35659, 49369, 63475, 77901, 92596, 107516, 122638, 137931]

================================> 

SAMP = 50

gcc_time_rs_i = [0.448, 1.234, 2.265, 3.497, 5.664, 8.679, 11.630, 12.462, 11.541, 13.539]
gcc_nbr_rs_i = [10142, 22491, 35673, 49395, 63519, 77963, 92674, 107612, 122750, 138067]

clang_time_rs_i = [0.377, 1.089, 2.061, 3.328, 5.131, 9.066, 11.464, 10.671, 12.934, 15.587]
clang_nbr_rs_i = [10142, 22491, 35673, 49395, 63519, 77963, 92674, 107612, 122750, 138067]

icx_time_rs_i = [0.223, 0.578, 1.094, 1.604, 2.197, 2.878, 3.502, 4.249, 5.070, 5.875]
icx_nbr_rs_i = [10142, 22491, 35673, 49395, 63519, 77963, 92674, 107612, 122750, 138067]

================================> 

SAMP = 100

gcc_time_rs_i = [0.868, 2.419, 4.376, 7.264, 10.664, 12.267, 15.447, 18.828, 22.522, 26.347]
gcc_nbr_rs_i = [10142, 22491, 35673, 49395, 63519, 77963, 92674, 107614, 122752, 138069]

clang_time_rs_i = [0.726, 2.046, 3.758, 6.019, 8.565, 11.695, 15.270, 19.109, 24.386, 29.300]
clang_nbr_rs_i = [10142, 22491, 35673, 49395, 63519, 77963, 92674, 107614, 122752, 138069]

icx_time_rs_i = [0.452, 1.176, 2.166, 3.196, 5.776, 8.016, 10.114, 11.629, 13.070, 14.038]
icx_nbr_rs_i = [10142, 22491, 35673, 49395, 63519, 77963, 92674, 107614, 122752, 138069]

================================================================================================================================

X = [10000, 20000, 30000, 40000, 50000, 60000, 70000, 80000, 90000, 100000]

gcc_time_samp_10  = [0.102, 0.272, 0.499, 0.753, 1.062, 1.436, 1.863, 2.159, 2.539, 2.964]
gcc_time_samp_50  = [0.448, 1.234, 2.265, 3.497, 5.664, 8.679, 11.630, 12.462, 11.541, 13.539]
gcc_time_samp_100 = [0.868, 2.419, 4.376, 7.264, 10.664, 12.267, 15.447, 18.828, 22.522, 26.347]
gcc_nbr = [10142, 22489, 35659, 49369, 63475, 77901, 92596, 107516, 122638, 137931]

clang_time_samp_10  = [0.108, 0.302, 0.550, 0.890, 1.268, 1.712, 2.221, 2.806, 3.396, 4.857]
clang_time_samp_50  = [0.377, 1.089, 2.061, 3.328, 5.131, 9.066, 11.464, 10.671, 12.934, 15.587]
clang_time_samp_100 = [0.726, 2.046, 3.758, 6.019, 8.565, 11.695, 15.270, 19.109, 24.386, 29.300]
clang_nbr = [10142, 22489, 35659, 49369, 63475, 77901, 92596, 107516, 122638, 137931]

icx_time_samp_10  = [0.050, 0.118, 0.211, 0.316, 0.454, 0.578, 0.722, 0.868, 1.051, 1.200]
icx_time_samp_50  = [0.223, 0.578, 1.094, 1.604, 2.197, 2.878, 3.502, 4.249, 5.070, 5.875]
icx_time_samp_100 = [0.452, 1.176, 2.166, 3.196, 5.776, 8.016, 10.114, 11.629, 13.070, 14.038]
icx_nbr = [10142, 22489, 35659, 49369, 63475, 77901, 92596, 107516, 122638, 137931]


================================================================================================================================
g++ -pg RiemannSiegel_Inlining.cpp -o RiemannSiegel_Inlining -O3


root@N-5CG1328LRC:~/tp_performance/optimisation/programs# ./RiemannSiegel_Inlining 10 100000 100
I estimate I will find 138067.558 zeros
I found 138069 Zeros in 26.904 seconds


gprof RiemannSiegel_Inlining  gmon.out > gcc_fast_inliningprofile_report.txt

=========================>

clang++ -pg RiemannSiegel_Inlining.cpp -o RiemannSiegel_Inlining -Ofast


root@N-5CG1328LRC:~/tp_performance/optimisation/programs# ./RiemannSiegel_Inlining 10 100000 100
I estimate I will find 138067.558 zeros
I found 138069 Zeros in 26.904 seconds


gprof RiemannSiegel_Inlining  gmon.out > clang_fast_inliningprofile_report.txt

=========================>

icx -lstdc++ -pg RiemannSiegel_Inlining.cpp -o RiemannSiegel_Inlining -Ofast


root@N-5CG1328LRC:~/tp_performance/optimisation/programs# ./RiemannSiegel_Inlining 10 100000 100                                     
I estimate I will find 138067.558 zeros
I found 138069 Zeros in 12.158 seconds



gprof RiemannSiegel_Inlining  gmon.out > icx_fast_inliningprofile_report.txt