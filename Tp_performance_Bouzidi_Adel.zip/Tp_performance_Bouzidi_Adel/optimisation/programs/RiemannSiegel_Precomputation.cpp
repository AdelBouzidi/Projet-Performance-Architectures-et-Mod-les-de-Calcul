#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>
#include <iostream>
#include <iomanip>
#include <cmath>
#include <complex>
#include <vector>
#include <cassert>

/*************************************************************************
* *


This code computes the number of zeros on the critical line of the Zeta function.
https://en.wikipedia.org/wiki/Riemann_zeta_function 

This is one of the most important and non resolved problem in mathematics : https://www.science-et-vie.com/article-magazine/voici-les-7-plus-grands-problemes-de-mathematiques-jamais-resolus

This problem has been the subject of one of the most important distributed computing project in the cloud : more than 10000 machines during 2 years. 
They used this algorithm: very well optimized.
This project failed, bitten by a smaller team that used a far better algorithm. 
The code is based on the Thesis of Glendon Ralph Pugh (1992) : https://web.viu.ca/pughg/thesis.d/masters.thesis.pdf

We can optimize the code in numerous ways, and obviously parallelize it. 

Remark: we do not compute the zeros: we count them to check that they are on the Riemann Line.
Remark: Andrew Odlyzko created a method that is far more efficient but too complex to be the subject of an algorithmetical tuning exercice. 

The exercise is to sample a region on the critical line to count how many times the function changes sign, so that there is at least 1 zero between 2 sampling points.
Here we use a constant sampling but you can recode entirely the way to proceed.

Only a correct (right) count matters, and the performance.

compile g++ RiemannSiegel.cpp -O -o RiemannSiegel
--------------------------------------------------------------------------
./RiemannSiegel 10 1000 100
I found 10142 Zeros in 3.459 seconds     # OK 
--------------------------------------------------------------------------
./RiemannSiegel 10 10000 10 
I found 10142 Zeros in 0.376 seconds     # OK
--------------------------------------------------------------------------
./RiemannSiegel 10 100000 10
I found 137931 Zeros in 6.934 seconds    # INCORRECT
--------------------------------------------------------------------------
./RiemannSiegel 10 100000 100
I found 138069 Zeros in 56.035 seconds   # OK
--------------------------------------------------------------------------
RiemannSiegel 10 1000000     need to find : 1747146     zeros
RiemannSiegel 10 10000000    need to find : 21136125    zeros
RiemannSiegel 10 100000000   need to find : 248888025   zeros
RiemannSiegel 10 1000000000  need to find : 2846548032  zeros
RiemannSiegel 10 10000000000 need to find : 32130158315 zeros


The more regions you validate and with the best timing, the more points you get.

The official world record of the zeros computed is 10^13 but with some FFTs and the method from Odlyzsko.
Compute time 1 year-core so an algortihm 10000*2*40 times more efficient than ZetaGrid's one. 

* *
*************************************************************************/

typedef unsigned long      ui32;
typedef unsigned long long ui64;

double dml_micros()
{
        static struct timezone tz;
        static struct timeval  tv;
        gettimeofday(&tv,&tz);
        return((tv.tv_sec*1000000.0)+tv.tv_usec);
}

int even(int n)
{
	if (n%2 == 0) return(1);
	else          return(-1);
}

/*

Explications de l'optimisation

Précomputation des constantes :
Au lieu de recalculer 1/48, 7/5760, etc., à chaque appel de theta(t), on les calcule une seule fois et les utilisons ensuite.
Cela améliore la performance en réduisant le nombre de divisions et d'opérations à effectuer à chaque appel de theta(t).
Utilisation de variables intermédiaires :
t_half est la moitié de t, utilisée pour les termes linéaires et logarithmiques.
t_inv est l'inverse de t, utilisé pour les puissances.

*/

double theta(double t)
{
    const double pi = 3.1415926535897932385;

    // Précomputation des constantes
    const double c1 = 1.0 / 48.0;
    const double c2 = 7.0 / 5760.0;
    const double c3 = 31.0 / 80640.0;
    const double c4 = 127.0 / 430080.0;
    const double c5 = 511.0 / 1216512.0;

    double t_half = t / 2.0;
    double t_inv = 1.0 / t;

    // Calcul de la fonction optimisée
    return t_half * log(t_half / pi) - t_half - pi / 8.0 +
           c1 * t_inv +
           c2 * pow(t_inv, 3) +
           c3 * pow(t_inv, 5) +
           c4 * pow(t_inv, 7) +
           c5 * pow(t_inv, 9);
}

/*


Explications de l'optimisation :
Pré-calcul des puissances de z : on a calculé toutes les puissances nécessaires de z au début de la fonction (de z^0 à z^48). De cette manière, on évite de 
recalculer les puissances plusieurs fois dans les différentes expressions, ce qui réduit la charge de travail.


*/


double C(int n, double z) {
    double z2 = pow(z, 2.0);   // z^2
    double z3 = z * z2;        // z^3
    double z4 = z2 * z2;       // z^4
    double z5 = z * z4;        // z^5
    double z6 = z2 * z4;       // z^6
    double z7 = z * z6;        // z^7
    double z8 = z2 * z6;       // z^8
    double z9 = z * z8;        // z^9
    double z10 = z2 * z8;      // z^10
    double z11 = z * z10;      // z^11
    double z12 = z2 * z10;     // z^12
    double z13 = z * z12;      // z^13
    double z14 = z2 * z12;     // z^14
    double z15 = z * z14;      // z^15
    double z16 = z2 * z14;     // z^16
    double z17 = z * z16;      // z^17
    double z18 = z2 * z16;     // z^18
    double z19 = z * z18;      // z^19
    double z20 = z2 * z18;     // z^20
    double z21 = z * z20;      // z^21
    double z22 = z2 * z20;     // z^22
    double z23 = z * z22;      // z^23
    double z24 = z2 * z22;     // z^24
    double z25 = z * z24;      // z^25
    double z26 = z2 * z24;     // z^26
    double z27 = z * z26;      // z^27
    double z28 = z2 * z26;     // z^28
    double z29 = z * z28;      // z^29
    double z30 = z2 * z28;     // z^30
    double z31 = z * z30;      // z^31
    double z32 = z2 * z30;     // z^32
    double z33 = z * z32;      // z^33
    double z34 = z2 * z32;     // z^34
    double z35 = z * z34;      // z^35
    double z36 = z2 * z34;     // z^36
    double z37 = z * z36;      // z^37
    double z38 = z2 * z36;     // z^38
    double z39 = z * z38;      // z^39
    double z40 = z2 * z38;     // z^40
    double z41 = z * z40;      // z^41
    double z42 = z2 * z40;     // z^42
    double z43 = z * z42;      // z^43
    double z44 = z2 * z42;     // z^44
    double z45 = z * z44;      // z^45
    double z46 = z2 * z44;     // z^46
    double z47 = z * z46;      // z^47
    double z48 = z2 * z46;     // z^48

    if (n == 0) {
        return .38268343236508977173 * 1.0
            + .43724046807752044936 * z2
            + .13237657548034352332 * z4
            - .01360502604767418865 * z6
            - .01356762197010358089 * z8
            - .00162372532314446528 * z10
            + .00029705353733379691 * z12
            + .00007943300879521470 * z14
            + .00000046556124614505 * z16
            - .00000143272516309551 * z18
            - .00000010354847112313 * z20
            + .00000001235792708386 * z22
            + .00000000178810838580 * z24
            - .00000000003391414390 * z26
            - .00000000001632663390 * z28
            - .00000000000037851093 * z30
            + .00000000000009327423 * z32
            + .00000000000000522184 * z34
            - .00000000000000033507 * z36
            - .00000000000000003412 * z38
            + .00000000000000000058 * z40
            + .00000000000000000015 * z42;
    }
    else if (n == 1) {
        return - .02682510262837534703 * z
            + .01378477342635185305 * z3
            + .03849125048223508223 * z5
            + .00987106629906207647 * z7
            - .00331075976085840433 * z9
            - .00146478085779541508 * z11
            - .00001320794062487696 * z13
            + .00005922748701847141 * z15
            + .00000598024258537345 * z17
            - .00000096413224561698 * z19
            - .00000018334733722714 * z21
            + .00000000446708756272 * z23
            + .00000000270963508218 * z25
            + .00000000007785288654 * z27
            - .00000000002343762601 * z29
            - .00000000000158301728 * z31
            + .00000000000012119942 * z33
            + .00000000000001458378 * z35
            - .00000000000000028786 * z37
            - .00000000000000008663 * z39
            - .00000000000000000084 * z41
            + .00000000000000000036 * z43
            + .00000000000000000001 * z45;
    }
    else if (n == 2) {
        return + .00518854283029316849 * 1.0
            + .00030946583880634746 * z2
            - .01133594107822937338 * z4
            + .00223304574195814477 * z6
            + .00519663740886233021 * z8
            + .00034399144076208337 * z10
            - .00059106484274705828 * z12
            - .00010229972547935857 * z14
            + .00002088839221699276 * z16
            + .00000592766549309654 * z18
            - .00000016423838362436 * z20
            - .00000015161199700941 * z22
            - .00000000590780369821 * z24
            + .00000000209115148595 * z26
            + .00000000017815649583 * z28
            - .00000000001616407246 * z30
            - .00000000000238069625 * z32
            + .00000000000005398265 * z34
            + .00000000000001975014 * z36
            + .00000000000000023333 * z38
            - .00000000000000011188 * z40
            - .00000000000000000416 * z42
            + .00000000000000000044 * z44
            + .00000000000000000003 * z46;
    }
    else if (n == 3) {
        return - .00133971609071945690 * z
            + .00374421513637939370 * z3
            - .00133031789193214681 * z5
            - .00226546607654717871 * z7
            + .00095484999985067304 * z9
            + .00060100384589636039 * z11
            - .00010128858286776622 * z13
            - .00006865733449299826 * z15
            + .00000059853667915386 * z17
            + .00000333165985123995 * z19
            + .00000021919289102435 * z21
            - .00000007890884245681 * z23
            - .00000000941468508130 * z25
            + .00000000095701162109 * z27
            + .00000000018763137453 * z29
            - .00000000000443783768 * z31
            - .00000000000224267385 * z33
            - .00000000000003627687 * z35
            + .00000000000001763981 * z37
            + .00000000000000079608 * z39
            - .00000000000000009420 * z41
            - .00000000000000000713 * z43
            + .00000000000000000033 * z45
            + .00000000000000000004 * z47;
    }
    else {
        return + .00046483389361763382 * 1.0
            - .00100566073653404708 * z2
            + .00024044856573725793 * z4
            + .00102830861497023219 * z6
            - .00076578610717556442 * z8
            - .00020365286803084818 * z10
            + .00023212290491068728 * z12
            + .00003260214424386520 * z14
            - .00002557906251794953 * z16
            - .00000410746443891574 * z18
            + .00000117811136403713 * z20
            + .00000024456561422485 * z22
            - .00000002391582476734 * z24
            - .00000000750521420704 * z26
            + .00000000013312279416 * z28
            + .00000000013440626754 * z30
            + .00000000000351377004 * z32
            - .00000000000151915445 * z34
            - .00000000000008915418 * z36
            + .00000000000001119589 * z38
            + .00000000000000105160 * z40
            - .00000000000000005179 * z42
            - .00000000000000000807 * z44
            + .00000000000000000011 * z46
            + .00000000000000000004 * z48;
    }
}

/*

Explications des améliorations :
Pré-calcul de sqrtTerm : on a déplacé le calcul de sqrt(t / (2.0 * pi)) hors des boucles et l'a stocké dans sqrtTerm. Cela permet de 
l'utiliser une seule fois pour calculer à la fois N et p.

Calcul de theta(t) : La fonction theta(t) est appelée une seule fois avant les boucles, et le résultat est stocké dans tt, évitant ainsi des appels répétitifs.

Optimisation de la boucle de ZZ : on a déplacé les calculs de 1.0 / sqrt(j) et cos(fmod(...)) dans la boucle sans autres changements majeurs, 
car cette partie est déjà relativement simple à calculer. Cependant, l'appel à fmod(tt - t * log(j), 2.0 * pi) reste dans la boucle.

Optimisation de la boucle de R : La puissance pow(2.0 * pi / t, 0.5) est pré-calculée et stockée dans commonFactor, ce qui évite de recalculer 
cette valeur dans chaque itération de la boucle. De plus, le facteur pow(2.0 * pi / t, 0.25) qui est utilisé à la fin de R est pré-calculé et stocké dans preFactor.

*/

double Z(double t, int n) {
    // Constants
    const double pi = 3.1415926535897932385;

    // Calcul du terme commun sqrt(t/(2*pi))
    double sqrtTerm = sqrt(t / (2.0 * pi));
    int N = (int)sqrtTerm;  // Calcul de N
    double p = sqrtTerm - N;  // Fractional part

    // Calcul de theta(t) une fois pour l'utiliser dans la boucle suivante
    double tt = theta(t);

    // Initialisation de ZZ
    double ZZ = 0.0;

    // Boucle pour la somme de la première partie (calcul de ZZ)
    for (int j = 1; j <= N; j++) {
        ZZ += 1.0 / sqrt((double)j) * cos(fmod(tt - t * log((double)j), 2.0 * pi));
    }

    // Multiplier par 2
    ZZ = 2.0 * ZZ;

    // Calcul de R en pré-calculant des termes
    double R = 0.0;
    double preFactor = pow(2.0 * pi / t, 0.25); // Facteur constant qui ne dépend pas de n
    double commonFactor = pow(2.0 * pi / t, 0.5); // Facteur utilisé dans les puissances

    // Boucle pour la somme de la deuxième partie (calcul de R)
    for (int k = 0; k <= n; k++) {
        double C_k = C(k, 2.0 * p - 1.0); // Appel à la fonction C(k, 2.0 * p - 1.0)
        R += C_k * pow(commonFactor, (double)k);
    }

    // Appliquer le facteur final à R
    R *= even(N - 1) * preFactor;

    // Retourner la somme de ZZ et R
    return ZZ + R;
}


/*
Explications des optimisations :
Pré-calcul des puissances k^c1 :

on a pré-calculé toutes les valeurs de p_k[k] = un / pow(k, c1) pour les indices de k de 1 à N. Ces puissances sont utilisées dans les 
boucles sum1 et sum2, et en les stockant dans un tableau, on évite de recalculer plusieurs fois la même valeur.
Calcul de sum1 et sum2 :

Dans sum1, la gestion des termes alternés (additions et soustractions) est conservée, mais en utilisant les valeurs pré-calculées de p_k[k], 
on évite des calculs redondants.
Pour sum2, on utilise également les valeurs de p_k[k] directement, ce qui permet de simplifier la structure de la boucle.
Optimisation de V1 et V2 :

Les calculs de V1 et V2 sont effectués dans deux boucles distinctes. Cependant, en pré-calculant V1 dans la première boucle et V2 dans 
la seconde, on a évité des recalculs et optimisé la gestion des coefficients.
*/


std::complex<double> test_zerod(const double zero, const int N)
{
    // Constantes
    std::complex<double> un(1.0, 0);
    std::complex<double> deux(2.0, 0);
    std::complex<double> c1(0.5, zero);

    // Pré-calcul de p1
    std::complex<double> p1 = un / (un - pow(deux, un - c1));

    // Pré-calcul des puissances k^c1
    std::vector<std::complex<double>> p_k(N + 1);
    for (int k = 1; k <= N; ++k) {
        p_k[k] = un / pow(k, c1);
    }

    // Calcul de sum1
    std::complex<double> sum1(0.0, 0.0);
    for (int k = 1; k <= N; ++k) {
        if (k % 2 == 0) {
            sum1 += p_k[k]; // Ajouter si k est pair
        } else {
            sum1 -= p_k[k]; // Soustraire si k est impair
        }
    }

    // Pré-calcul des coefficients V1 et V2
    std::vector<double> V1(N), V2(N);
    double coef = 1.0;
    double up = N;
    double dw = 1.0;
    double su = 0.0;

    // Calcul de V1 et de la somme su
    for (int k = 0; k < N; ++k) {
        coef *= up--;
        coef /= dw++;
        V1[k] = coef;
        su += coef;
    }

    // Calcul de V2
    for (int k = 0; k < N; ++k) {
        V2[k] = su;
        su -= V1[k];
    }

    // Calcul de sum2
    std::complex<double> sum2(0.0, 0.0);
    for (int k = N + 1; k <= 2 * N; ++k) {
        std::complex<double> p2 = p_k[k]; // Réutilisation de p_k
        double ek = V2[k - N - 1];
        std::complex<double> c3(ek, 0.0);
        std::complex<double> c4 = p2 * c3;

        if (k % 2 == 0) {
            sum2 += c4; // Ajouter si k est pair
        } else {
            sum2 -= c4; // Soustraire si k est impair
        }
    }

    // Résultat final
    std::complex<double> rez = (sum1 + sum2 / pow(deux, N)) * p1;
    return rez;
}

void test_one_zero(double t)
{
	double RS=Z(t,4);
	std::complex <double> c1=test_zerod(t,10);
	std::complex <double> c2=test_zerod(t,100);
	std::complex <double> c3=test_zerod(t,1000);
	std::cout << std::setprecision(15);
	std::cout << "RS= "<<" "<<RS<<" TEST10= "<< c1 << " TEST100=" << c2 << " TEST1000=" << c3 << std::endl;
	
}

void tests_zeros()
{
	test_one_zero(14.1347251417346937904572519835625);
	test_one_zero(101.3178510057313912287854479402924);
	test_one_zero(1001.3494826377827371221033096531063);
	test_one_zero(10000.0653454145353147502287213889928);

}

/*
	An option to better the performance of Z(t) for large values of t is to simplify the equations
	to validate we present a function that tests the known zeros :  look at https://www.lmfdb.org/zeros/zeta/?limit=10&N=10
	We should obtain 0.0
        no need to test many zeros. In case of a bug the column 2 will show large values instead of values close to 0 like with the original code
	Observe that when t increases the accuracy increases until the limits of the IEEE 754 norm block us, we should work with extended precision
	But here a few digits of precision are enough to count the zeros, only on rare cases the _float128 should be used
	But this limitation only appears very far and with the constraint of resources it won't be possible to reach this region. 
	----------------------------------------------------------------------------------------------------------------------
	value in double			should be 0.0		 value in strings: LMFDB all the digits are corrects
        14.13472514173469463117        -0.00000248590756340983   14.1347251417346937904572519835625
        21.02203963877155601381        -0.00000294582959536882   21.0220396387715549926284795938969
        25.01085758014568938279        -0.00000174024500421144   25.0108575801456887632137909925628
       178.37740777609997167019         0.00000000389177887139   178.3774077760999772858309354141843
       179.91648402025700193008         0.00000000315651035865   179.9164840202569961393400366120511
       182.20707848436646258961         0.00000000214091858131   182.207078484366461915407037226988
 371870901.89642333984375000000         0.00000060389888876036   371870901.8964233245801283081720385309201
 371870902.28132432699203491211        -0.00000083698274928878   371870902.2813243157291041227177012243450
 371870902.52132433652877807617        -0.00000046459056067712   371870902.5213243412580878836297930128983
*/
/*
char line[1024];
void test_fileof_zeros(const char *fname)
{
	FILE *fi=fopen(fname,"r");
	assert(fi!=NULL);
	for(;;){
		double t,RS;
		fgets(line,1000,fi);
		if(feof(fi))break;
		sscanf(line,"%lf",&t);
		RS=Z(t,4);
		printf(" %30.20lf %30.20lf   %s",t,RS,line);

	}
	fclose(fi);
}
*/
int main(int argc,char **argv)
{
	double LOWER,UPPER,SAMP;
	const double pi = 3.1415926535897932385;
	//tests_zeros();
	//test_fileof_zeros("ZEROS");
	try {
		LOWER=std::atof(argv[1]);
		UPPER=std::atof(argv[2]);
		SAMP =std::atof(argv[3]);
	}
	catch (...) {
                std::cout << argv[0] << " START END SAMPLING" << std::endl;
                return -1;
        }
	double estimate_zeros=theta(UPPER)/pi;
	printf("I estimate I will find %1.3lf zeros\n",estimate_zeros);

	double STEP = 1.0/SAMP;
	ui64   NUMSAMPLES=floor((UPPER-LOWER)*SAMP+1.0);
	double prev=0.0;
	double count=0.0;
	double t1=dml_micros();
	for (double t=LOWER;t<=UPPER;t+=STEP){
		double zout=Z(t,4);
		if(t>LOWER){
			if(   ((zout<0.0)and(prev>0.0))
			    or((zout>0.0)and(prev<0.0))){
				//printf("%20.6lf  %20.12lf %20.12lf\n",t,prev,zout);
				count++;
			}
		}
		prev=zout;
	}
	double t2=dml_micros();
	printf("I found %1.0lf Zeros in %.3lf seconds\n",count,(t2-t1)/1000000.0);
	return(0);
}



