#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>
#include <iostream>
#include <iomanip>
#include <cmath>
#include <complex>
#include <vector>
#include <cassert>

/*************************************************************************
* *


This code computes the number of zeros on the critical line of the Zeta function.
https://en.wikipedia.org/wiki/Riemann_zeta_function 

This is one of the most important and non resolved problem in mathematics : https://www.science-et-vie.com/article-magazine/voici-les-7-plus-grands-problemes-de-mathematiques-jamais-resolus

This problem has been the subject of one of the most important distributed computing project in the cloud : more than 10000 machines during 2 years. 
They used this algorithm: very well optimized.
This project failed, bitten by a smaller team that used a far better algorithm. 
The code is based on the Thesis of Glendon Ralph Pugh (1992) : https://web.viu.ca/pughg/thesis.d/masters.thesis.pdf

We can optimize the code in numerous ways, and obviously parallelize it. 

Remark: we do not compute the zeros: we count them to check that they are on the Riemann Line.
Remark: Andrew Odlyzko created a method that is far more efficient but too complex to be the subject of an algorithmetical tuning exercice. 

The exercise is to sample a region on the critical line to count how many times the function changes sign, so that there is at least 1 zero between 2 sampling points.
Here we use a constant sampling but you can recode entirely the way to proceed.

Only a correct (right) count matters, and the performance.

compile g++ RiemannSiegel.cpp -O -o RiemannSiegel
--------------------------------------------------------------------------
./RiemannSiegel 10 1000 100
I found 10142 Zeros in 3.459 seconds     # OK 
--------------------------------------------------------------------------
./RiemannSiegel 10 10000 10 
I found 10142 Zeros in 0.376 seconds     # OK
--------------------------------------------------------------------------
./RiemannSiegel 10 100000 10
I found 137931 Zeros in 6.934 seconds    # INCORRECT
--------------------------------------------------------------------------
./RiemannSiegel 10 100000 100
I found 138069 Zeros in 56.035 seconds   # OK
--------------------------------------------------------------------------
RiemannSiegel 10 1000000     need to find : 1747146     zeros
RiemannSiegel 10 10000000    need to find : 21136125    zeros
RiemannSiegel 10 100000000   need to find : 248888025   zeros
RiemannSiegel 10 1000000000  need to find : 2846548032  zeros
RiemannSiegel 10 10000000000 need to find : 32130158315 zeros


The more regions you validate and with the best timing, the more points you get.

The official world record of the zeros computed is 10^13 but with some FFTs and the method from Odlyzsko.
Compute time 1 year-core so an algortihm 10000*2*40 times more efficient than ZetaGrid's one. 

* *
*************************************************************************/

typedef unsigned long      ui32;
typedef unsigned long long ui64;

double dml_micros()
{
        static struct timezone tz;
        static struct timeval  tv;
        gettimeofday(&tv,&tz);
        return((tv.tv_sec*1000000.0)+tv.tv_usec);
}

int even(int n)
{
	if (n%2 == 0) return(1);
	else          return(-1);
}

double theta(double t)
{
	const double pi = 3.1415926535897932385;
	return(t/2.0*log(t/2.0/pi) - t/2.0 - pi/8.0 + 1.0/48.0/t + 7.0/5760.0/pow(t,3.0) + 31.0/80640.0/powl(t,5.0) +127.0/430080.0/powl(t,7.0)+511.0/1216512.0/powl(t,9.0));
	//https://oeis.org/A282898  // numerators
	//https://oeis.org/A114721  // denominators
}


double C(int n, double z){
	if (n==0)
		  return(.38268343236508977173 * pow(z, 0.0)
			+.43724046807752044936 * pow(z, 2.0)
			+.13237657548034352332 * pow(z, 4.0)
			-.01360502604767418865 * pow(z, 6.0)
			-.01356762197010358089 * pow(z, 8.0)
			-.00162372532314446528 * pow(z,10.0)
			+.00029705353733379691 * pow(z,12.0)
			+.00007943300879521470 * pow(z,14.0)
			+.00000046556124614505 * pow(z,16.0)
			-.00000143272516309551 * pow(z,18.0)
			-.00000010354847112313 * pow(z,20.0)
			+.00000001235792708386 * pow(z,22.0)
			+.00000000178810838580 * pow(z,24.0)
			-.00000000003391414390 * pow(z,26.0)
			-.00000000001632663390 * pow(z,28.0)
			-.00000000000037851093 * pow(z,30.0)
			+.00000000000009327423 * pow(z,32.0)
			+.00000000000000522184 * pow(z,34.0)
			-.00000000000000033507 * pow(z,36.0)
			-.00000000000000003412 * pow(z,38.0)
			+.00000000000000000058 * pow(z,40.0)
			+.00000000000000000015 * pow(z,42.0));
	else if (n==1)
		 return(-.02682510262837534703 * pow(z, 1.0)
			+.01378477342635185305 * pow(z, 3.0)
			+.03849125048223508223 * pow(z, 5.0)
			+.00987106629906207647 * pow(z, 7.0)
			-.00331075976085840433 * pow(z, 9.0)
			-.00146478085779541508 * pow(z,11.0)
			-.00001320794062487696 * pow(z,13.0)
			+.00005922748701847141 * pow(z,15.0)
			+.00000598024258537345 * pow(z,17.0)
			-.00000096413224561698 * pow(z,19.0)
			-.00000018334733722714 * pow(z,21.0)
			+.00000000446708756272 * pow(z,23.0)
			+.00000000270963508218 * pow(z,25.0)
			+.00000000007785288654 * pow(z,27.0)
			-.00000000002343762601 * pow(z,29.0)
			-.00000000000158301728 * pow(z,31.0)
			+.00000000000012119942 * pow(z,33.0)
			+.00000000000001458378 * pow(z,35.0)
			-.00000000000000028786 * pow(z,37.0)
			-.00000000000000008663 * pow(z,39.0)
			-.00000000000000000084 * pow(z,41.0)
			+.00000000000000000036 * pow(z,43.0)
			+.00000000000000000001 * pow(z,45.0));
else if (n==2)
		 return(+.00518854283029316849 * pow(z, 0.0)
			+.00030946583880634746 * pow(z, 2.0)
			-.01133594107822937338 * pow(z, 4.0)
			+.00223304574195814477 * pow(z, 6.0)
			+.00519663740886233021 * pow(z, 8.0)
			+.00034399144076208337 * pow(z,10.0)
			-.00059106484274705828 * pow(z,12.0)
			-.00010229972547935857 * pow(z,14.0)
			+.00002088839221699276 * pow(z,16.0)
			+.00000592766549309654 * pow(z,18.0)
			-.00000016423838362436 * pow(z,20.0)
			-.00000015161199700941 * pow(z,22.0)
			-.00000000590780369821 * pow(z,24.0)
			+.00000000209115148595 * pow(z,26.0)
			+.00000000017815649583 * pow(z,28.0)
			-.00000000001616407246 * pow(z,30.0)
			-.00000000000238069625 * pow(z,32.0)
			+.00000000000005398265 * pow(z,34.0)
			+.00000000000001975014 * pow(z,36.0)
			+.00000000000000023333 * pow(z,38.0)
			-.00000000000000011188 * pow(z,40.0)
			-.00000000000000000416 * pow(z,42.0)
			+.00000000000000000044 * pow(z,44.0)
			+.00000000000000000003 * pow(z,46.0));
else if (n==3)
		 return(-.00133971609071945690 * pow(z, 1.0)
			+.00374421513637939370 * pow(z, 3.0)
			-.00133031789193214681 * pow(z, 5.0)
			-.00226546607654717871 * pow(z, 7.0)
			+.00095484999985067304 * pow(z, 9.0)
			+.00060100384589636039 * pow(z,11.0)
			-.00010128858286776622 * pow(z,13.0)
			-.00006865733449299826 * pow(z,15.0)
			+.00000059853667915386 * pow(z,17.0)
			+.00000333165985123995 * pow(z,19.0)
			+.00000021919289102435 * pow(z,21.0)
			-.00000007890884245681 * pow(z,23.0)
			-.00000000941468508130 * pow(z,25.0)
			+.00000000095701162109 * pow(z,27.0)
			+.00000000018763137453 * pow(z,29.0)
			-.00000000000443783768 * pow(z,31.0)
			-.00000000000224267385 * pow(z,33.0)
			-.00000000000003627687 * pow(z,35.0)
			+.00000000000001763981 * pow(z,37.0)
			+.00000000000000079608 * pow(z,39.0)
			-.00000000000000009420 * pow(z,41.0)
			-.00000000000000000713 * pow(z,43.0)
			+.00000000000000000033 * pow(z,45.0)
			+.00000000000000000004 * pow(z,47.0));
else
		 return(+.00046483389361763382 * pow(z, 0.0)
			-.00100566073653404708 * pow(z, 2.0)
			+.00024044856573725793 * pow(z, 4.0)
			+.00102830861497023219 * pow(z, 6.0)
			-.00076578610717556442 * pow(z, 8.0)
			-.00020365286803084818 * pow(z,10.0)
			+.00023212290491068728 * pow(z,12.0)
			+.00003260214424386520 * pow(z,14.0)
			-.00002557906251794953 * pow(z,16.0)
			-.00000410746443891574 * pow(z,18.0)
			+.00000117811136403713 * pow(z,20.0)
			+.00000024456561422485 * pow(z,22.0)
			-.00000002391582476734 * pow(z,24.0)
			-.00000000750521420704 * pow(z,26.0)
			+.00000000013312279416 * pow(z,28.0)
			+.00000000013440626754 * pow(z,30.0)
			+.00000000000351377004 * pow(z,32.0)
			-.00000000000151915445 * pow(z,34.0)
			-.00000000000008915418 * pow(z,36.0)
			+.00000000000001119589 * pow(z,38.0)
			+.00000000000000105160 * pow(z,40.0)
			-.00000000000000005179 * pow(z,42.0)
			-.00000000000000000807 * pow(z,44.0)
			+.00000000000000000011 * pow(z,46.0)
			+.00000000000000000004 * pow(z,48.0));
}

/*

Explication des optimisations :
1. Loop Unrolling pour la boucle de ZZ :
Avant l'optimisation : La boucle originale exécute une itération par tour pour calculer la somme ZZ.

Après l'optimisation : on a fait un déroulement de boucle en traitant quatre éléments à chaque itération de la boucle (j, j+1, j+2, j+3). 
Cela réduit le nombre d'incréments et de tests de condition dans la boucle.

En effet, au lieu d'effectuer 4 itérations distinctes, on les combine en une seule itération. Cela réduit les appels à sqrt, log et cos, 
et on diminue aussi les conditions de la boucle et les incréments d'index de boucle.

Gestion des restes : Si N n'est pas un multiple de 4, la boucle for (; j <= N; ++j) s'assure que les derniers éléments sont traités correctement.

2. Boucle de R :
La boucle qui calcule R dépend de la fonction C(k, 2.0 * p - 1.0), qui semble calculer des coefficients spécifiques. Ces calculs ne sont 
pas optimisables par le loop unrolling, car la fonction C est appelée avec des valeurs différentes pour chaque itération. Par conséquent, 
on n'applique pas le loop unrolling à cette boucle.

*/

double Z(double t, int n) {
    const double pi = 3.1415926535897932385;
    int N = sqrt(t / (2.0 * pi));
    double p = sqrt(t / (2.0 * pi)) - N;
    double tt = theta(t);
    double ZZ = 0.0;

    // Cas où N < 4 : utiliser la boucle simple
    if (N < 4) {
        for (int j = 1; j <= N; ++j) {
            ZZ += 1.0 / sqrt((double)j) * cos(fmod(tt - t * log((double)j), 2.0 * pi));
        }
    } 
    // Cas où N >= 4 : appliquer le loop unrolling
    else {
        int j = 1;
        for (; j <= N - 3; j += 4) {
            ZZ += 1.0 / sqrt((double)j) * cos(fmod(tt - t * log((double)j), 2.0 * pi));
            ZZ += 1.0 / sqrt((double)(j + 1)) * cos(fmod(tt - t * log((double)(j + 1)), 2.0 * pi));
            ZZ += 1.0 / sqrt((double)(j + 2)) * cos(fmod(tt - t * log((double)(j + 2)), 2.0 * pi));
            ZZ += 1.0 / sqrt((double)(j + 3)) * cos(fmod(tt - t * log((double)(j + 3)), 2.0 * pi));
        }

        // Traiter les éléments restants (si N n'est pas un multiple de 4)
        for (; j <= N; ++j) {
            ZZ += 1.0 / sqrt((double)j) * cos(fmod(tt - t * log((double)j), 2.0 * pi));
        }
    }

    ZZ = 2.0 * ZZ;

    // Calcul de R
    double R = 0.0;
    for (int k = 0; k <= n; ++k) {
        R += C(k, 2.0 * p - 1.0) * pow(2.0 * pi / t, ((double)k) * 0.5);
    }

    R = even(N - 1) * pow(2.0 * pi / t, 0.25) * R;

    return ZZ + R;
}


/*
Optimisations réalisées

Le code a été optimisé de plusieurs façons pour améliorer ses performances :

Déroulement des boucles :

Les boucles principales qui répètent un calcul un certain nombre de fois (noté k) ont été modifiées pour traiter quatre calculs à la fois plutôt qu'un par un. 
Cette technique, appelée "déroulement de boucle", permet de réduire le temps passé à gérer la boucle elle-même (conditions, incréments), ce qui accélère l'exécution.
Ces quatre calculs sont effectués en parallèle, ce qui signifie que le processeur peut les traiter simultanément, améliorant encore les performances.
Traitement des cas particuliers :

Lorsque le nombre total de calculs n'est pas un multiple de quatre (par exemple, si on doit faire 5 calculs), une boucle classique est utilisée pour traiter 
les calculs restants. Cela garantit que tous les calculs sont effectués, même si le nombre total n'est pas divisible par quatre.
Réduction des calculs redondants :

Certains calculs, comme p2 et c3, sont effectués plusieurs fois dans le code. Pour éviter de les recalculer à chaque fois, leurs résultats sont calculés une 
seule fois au début et stockés pour être réutilisés. Cette technique, appelée "précalcul", permet d'économiser du temps de calcul.
Optimisation des vecteurs V1 et V2 :

Les vecteurs V1 et V2 sont des listes de valeurs utilisées dans les calculs. La façon dont ces vecteurs sont calculés et utilisés a été améliorée pour réduire 
le temps de calcul global.
*/
std::complex<double> test_zerod(const double zero, const int N) {
    std::complex<double> un(1.0, 0);
    std::complex<double> deux(2.0, 0);
    std::complex<double> c1(0.5, zero);
    std::complex<double> sum1(0.0, 0.0);
    std::complex<double> sum2(0.0, 0.0);
    std::complex<double> p1 = un / (un - pow(deux, un - c1));

    // Boucle 1 : Calcul de sum1 avec unrolling
    int k = 1;
    for (; k <= N - 3; k += 4) {
        std::complex<double> p2_1 = un / pow(k, c1);
        std::complex<double> p2_2 = un / pow(k + 1, c1);
        std::complex<double> p2_3 = un / pow(k + 2, c1);
        std::complex<double> p2_4 = un / pow(k + 3, c1);

        sum1 += ((k % 2 == 0) ? p2_1 : -p2_1);
        sum1 += ((k + 1) % 2 == 0 ? p2_2 : -p2_2);
        sum1 += ((k + 2) % 2 == 0 ? p2_3 : -p2_3);
        sum1 += ((k + 3) % 2 == 0 ? p2_4 : -p2_4);
    }

    // Traiter les restes
    for (; k <= N; ++k) {
        std::complex<double> p2 = un / pow(k, c1);
        sum1 += ((k % 2 == 0) ? p2 : -p2);
    }

    // Calcul des coefficients V1 et V2
    std::vector<double> V1(N);
    std::vector<double> V2(N);
    double coef = 1.0;
    double up = N;
    double dw = 1.0;
    double su = 0.0;

    for (int k = 0; k < N; ++k) {
        coef *= up--;
        coef /= dw++;
        V1[k] = coef;
        su += coef;
    }

    for (int k = 0; k < N; ++k) {
        V2[k] = su;
        su -= V1[k];
    }

    // Boucle 2 : Calcul de sum2 avec unrolling
    for (k = N + 1; k <= 2 * N - 3; k += 4) {
        std::complex<double> p2_1 = un / pow(k, c1);
        std::complex<double> p2_2 = un / pow(k + 1, c1);
        std::complex<double> p2_3 = un / pow(k + 2, c1);
        std::complex<double> p2_4 = un / pow(k + 3, c1);

        double ek1 = V2[k - N - 1];
        double ek2 = V2[k - N];
        double ek3 = V2[k - N + 1];
        double ek4 = V2[k - N + 2];

        std::complex<double> c3_1(ek1, 0.0);
        std::complex<double> c3_2(ek2, 0.0);
        std::complex<double> c3_3(ek3, 0.0);
        std::complex<double> c3_4(ek4, 0.0);

        sum2 += ((k % 2 == 0) ? (p2_1 * c3_1) : -(p2_1 * c3_1));
        sum2 += ((k + 1) % 2 == 0 ? (p2_2 * c3_2) : -(p2_2 * c3_2));
        sum2 += ((k + 2) % 2 == 0 ? (p2_3 * c3_3) : -(p2_3 * c3_3));
        sum2 += ((k + 3) % 2 == 0 ? (p2_4 * c3_4) : -(p2_4 * c3_4));
    }

    // Traiter les restes
    for (; k <= 2 * N; ++k) {
        std::complex<double> p2 = un / pow(k, c1);
        double ek = V2[k - N - 1];
        std::complex<double> c3(ek, 0.0);
        sum2 += ((k % 2 == 0) ? (p2 * c3) : -(p2 * c3));
    }

    // Calcul final
    std::complex<double> rez = (sum1 + sum2 / pow(deux, N)) * p1;
    return rez;
}

void test_one_zero(double t)
{
	double RS=Z(t,4);
	std::complex <double> c1=test_zerod(t,10);
	std::complex <double> c2=test_zerod(t,100);
	std::complex <double> c3=test_zerod(t,1000);
	std::cout << std::setprecision(15);
    std::cout << "RS= "<<" "<<RS<<" TEST10= "<< c1 << " TEST100=" << c2 << " TEST1000=" << c3 << std::endl;
	
}

void tests_zeros()
{
	test_one_zero(14.1347251417346937904572519835625);
        test_one_zero(101.3178510057313912287854479402924);
        test_one_zero(1001.3494826377827371221033096531063);
        test_one_zero(10000.0653454145353147502287213889928);

}

/*
	An option to better the performance of Z(t) for large values of t is to simplify the equations
	to validate we present a function that tests the known zeros :  look at https://www.lmfdb.org/zeros/zeta/?limit=10&N=10
	We should obtain 0.0
        no need to test many zeros. In case of a bug the column 2 will show large values instead of values close to 0 like with the original code
	Observe that when t increases the accuracy increases until the limits of the IEEE 754 norm block us, we should work with extended precision
	But here a few digits of precision are enough to count the zeros, only on rare cases the _float128 should be used
	But this limitation only appears very far and with the constraint of resources it won't be possible to reach this region. 
	----------------------------------------------------------------------------------------------------------------------
	value in double			should be 0.0		 value in strings: LMFDB all the digits are corrects
        14.13472514173469463117        -0.00000248590756340983   14.1347251417346937904572519835625
        21.02203963877155601381        -0.00000294582959536882   21.0220396387715549926284795938969
        25.01085758014568938279        -0.00000174024500421144   25.0108575801456887632137909925628
       178.37740777609997167019         0.00000000389177887139   178.3774077760999772858309354141843
       179.91648402025700193008         0.00000000315651035865   179.9164840202569961393400366120511
       182.20707848436646258961         0.00000000214091858131   182.207078484366461915407037226988
 371870901.89642333984375000000         0.00000060389888876036   371870901.8964233245801283081720385309201
 371870902.28132432699203491211        -0.00000083698274928878   371870902.2813243157291041227177012243450
 371870902.52132433652877807617        -0.00000046459056067712   371870902.5213243412580878836297930128983
*/

/*

Optimisations effectuées :
Unrolling sur 4 lignes :

La boucle principale tente de lire 4 lignes en une seule itération.
Cela minimise les appels fréquents à fgets() et améliore l'efficacité.
Buffer temporaire pour les lignes :

Un tableau lines[4][1024] stocke temporairement jusqu'à 4 lignes pour le traitement par lots.
Évaluation et impression en lot :

Les appels à Z(t, 4) sont effectués en lot sur les 4 lignes lues.
Les résultats sont ensuite imprimés séquentiellement.
Gestion des cas où moins de 4 lignes sont lues :

Le code traite correctement les cas où le fichier se termine avant une itération complète (par exemple, si seulement 1, 2, ou 3 lignes restent).

*/
/*
char line[1024];
void test_fileof_zeros(const char *fname) {
    FILE *fi = fopen(fname, "r");
    assert(fi != NULL);

    double t[4], RS[4];
    char lines[4][1024]; // Buffer pour unrolling

    while (true) {
        int readCount = 0;

        // Lire 4 lignes à la fois (ou moins si fin de fichier)
        for (int i = 0; i < 4; ++i) {
            if (fgets(lines[i], 1000, fi) == NULL) break;
            sscanf(lines[i], "%lf", &t[i]);
            ++readCount;
        }

        // Si aucune ligne n'a été lue, terminer
        if (readCount == 0) break;

        // Calculer Z(t) pour les lignes lues
        for (int i = 0; i < readCount; ++i) {
            RS[i] = Z(t[i], 4);
        }

        // Imprimer les résultats
        for (int i = 0; i < readCount; ++i) {
            printf(" %30.20lf %30.20lf   %s", t[i], RS[i], lines[i]);
        }

        // Arrêter si la dernière lecture a atteint la fin du fichier
        if (feof(fi)) break;
    }

    fclose(fi);
}
*/

/*

Optimisations réalisées :
Unrolling de la boucle :

La boucle principale a été déroulée pour calculer Z(t, 4) pour quatre valeurs consécutives de t dans chaque itération.
Cela réduit les sauts de boucle et le nombre total d'itérations.
Réduction des calculs :

La boucle vérifie directement les changements de signe pour quatre valeurs de zout à la fois, réduisant les comparaisons et mises à jour de prev.
Minimisation des appels à Z(t, 4) :

La fonction coûteuse Z(t, 4) est appelée une seule fois par point, mais pour quatre points consécutifs dans chaque itération.
Maintenance de la lisibilité :

Le code reste clair et peut facilement être ajusté pour un unrolling plus important (par exemple, 8 étapes par boucle).

*/

int main(int argc, char **argv) {
    double LOWER, UPPER, SAMP;
    const double pi = 3.1415926535897932385;

    try {
        LOWER = std::atof(argv[1]);
        UPPER = std::atof(argv[2]);
        SAMP = std::atof(argv[3]);
    } catch (...) {
        std::cout << argv[0] << " START END SAMPLING" << std::endl;
        return -1;
    }

    double estimate_zeros = theta(UPPER) / pi;
    printf("I estimate I will find %1.3lf zeros\n", estimate_zeros);

    double STEP = 1.0 / SAMP;
    ui64 NUMSAMPLES = floor((UPPER - LOWER) * SAMP + 1.0);

    double prev = 0.0;
    double count = 0.0;

    double t1 = dml_micros();

    // Unrolling the loop
    for (double t = LOWER; t <= UPPER; t += 4 * STEP) {
        // Compute Z(t) for 4 consecutive points
        double zout1 = Z(t, 4);
        double zout2 = Z(t + STEP, 4);
        double zout3 = Z(t + 2 * STEP, 4);
        double zout4 = Z(t + 3 * STEP, 4);

        // Check for zero crossings in unrolled steps
        if (t > LOWER) {
            if ((zout1 < 0.0 && prev > 0.0) || (zout1 > 0.0 && prev < 0.0)) count++;
            if ((zout2 < 0.0 && zout1 > 0.0) || (zout2 > 0.0 && zout1 < 0.0)) count++;
            if ((zout3 < 0.0 && zout2 > 0.0) || (zout3 > 0.0 && zout2 < 0.0)) count++;
            if ((zout4 < 0.0 && zout3 > 0.0) || (zout4 > 0.0 && zout3 < 0.0)) count++;
        }

        // Update `prev` for the next iteration
        prev = zout4;
    }

    double t2 = dml_micros();
    printf("I found %1.0lf Zeros in %.3lf seconds\n", count, (t2 - t1) / 1000000.0);

    return 0;
}




