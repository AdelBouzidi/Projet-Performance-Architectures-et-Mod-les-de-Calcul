#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>
#include <iostream>
#include <iomanip>
#include <cmath>
#include <complex>
#include <vector>
#include <cassert>
#include <cstdlib>
#include <cstdio>
#include <ctime>
#include <stdio.h>
#include <assert.h>

/*************************************************************************
* *


This code computes the number of zeros on the critical line of the Zeta function.
https://en.wikipedia.org/wiki/Riemann_zeta_function 

This is one of the most important and non resolved problem in mathematics : https://www.science-et-vie.com/article-magazine/voici-les-7-plus-grands-problemes-de-mathematiques-jamais-resolus

This problem has been the subject of one of the most important distributed computing project in the cloud : more than 10000 machines during 2 years. 
They used this algorithm: very well optimized.
This project failed, bitten by a smaller team that used a far better algorithm. 
The code is based on the Thesis of Glendon Ralph Pugh (1992) : https://web.viu.ca/pughg/thesis.d/masters.thesis.pdf

We can optimize the code in numerous ways, and obviously parallelize it. 

Remark: we do not compute the zeros: we count them to check that they are on the Riemann Line.
Remark: Andrew Odlyzko created a method that is far more efficient but too complex to be the subject of an algorithmetical tuning exercice. 

The exercise is to sample a region on the critical line to count how many times the function changes sign, so that there is at least 1 zero between 2 sampling points.
Here we use a constant sampling but you can recode entirely the way to proceed.

Only a correct (right) count matters, and the performance.

compile g++ RiemannSiegel.cpp -O -o RiemannSiegel
--------------------------------------------------------------------------
./RiemannSiegel 10 1000 100
I found 10142 Zeros in 3.459 seconds     # OK 
--------------------------------------------------------------------------
./RiemannSiegel 10 10000 10 
I found 10142 Zeros in 0.376 seconds     # OK
--------------------------------------------------------------------------
./RiemannSiegel 10 100000 10
I found 137931 Zeros in 6.934 seconds    # INCORRECT
--------------------------------------------------------------------------
./RiemannSiegel 10 100000 100
I found 138069 Zeros in 56.035 seconds   # OK
--------------------------------------------------------------------------
RiemannSiegel 10 1000000     need to find : 1747146     zeros
RiemannSiegel 10 10000000    need to find : 21136125    zeros
RiemannSiegel 10 100000000   need to find : 248888025   zeros
RiemannSiegel 10 1000000000  need to find : 2846548032  zeros
RiemannSiegel 10 10000000000 need to find : 32130158315 zeros


The more regions you validate and with the best timing, the more points you get.

The official world record of the zeros computed is 10^13 but with some FFTs and the method from Odlyzsko.
Compute time 1 year-core so an algortihm 10000*2*40 times more efficient than ZetaGrid's one. 

* *
*************************************************************************/

typedef unsigned long      ui32;
typedef unsigned long long ui64;

double dml_micros()
{
        static struct timezone tz;
        static struct timeval  tv;
        gettimeofday(&tv,&tz);
        return((tv.tv_sec*1000000.0)+tv.tv_usec);
}

int even(int n)
{
	if (n%2 == 0) return(1);
	else          return(-1);
}

/*

Explications des Modifications :
Pré-calcul des puissances de 1/t :

Les valeurs de 1/t, 1/t^2, 1/t^3, etc., sont calculées une seule fois au début de la fonction. Cela permet de réutiliser ces termes 
dans les multiples parties de l'expression de theta, réduisant ainsi le nombre d'opérations répétées et les appels de fonctions comme pow(). 
Calculer ces puissances explicitement améliore la clarté et la vitesse du programme.
Réorganisation des termes de l'expression :

Les termes de l'expression ont été regroupés de manière logique pour éviter des calculs inutiles et les erreurs d'arrondi. Le terme 
log(t / (2.0 * pi)) est calculé une seule fois, et tous les autres termes sont calculés avec les pré-calculs de puissances de t.
Optimisation des puissances de t :

En évitant de recalculer plusieurs fois des puissances de t via des appels à la fonction pow(), la fonction devient plus rapide.
 L'utilisation de variables intermédiaires pour stocker les puissances permet de réduire l'utilisation de la fonction pow(), qui est relativement coûteuse en termes de calcul.
Meilleure gestion des erreurs d'arrondi :

Le réarrangement des termes et l'utilisation d'opérations sur des variables intermédiaires de type double améliorent la précision 
en évitant des pertes significatives dues à des arrondis successifs (notamment pour les petites puissances de 1/t).
Clarification du calcul :

En séparant les calculs intermédiaires (puissances de 1/t), le code devient plus lisible et chaque opération est clairement définie. 
Cela peut également faciliter l'optimisation par des compilateurs modernes, qui peuvent mieux utiliser les registres CPU et le cache mémoire.

*/

double theta(double t)
{
    const double pi = 3.1415926535897932385;

    // Réarrangement des termes pour réduire les erreurs d'arrondi et améliorer les calculs
    double t_inv = 1.0 / t;  // Calcul préalable de 1/t, utilisé dans plusieurs termes
    double t_inv_sq = t_inv * t_inv;  // 1/t^2
    double t_inv_cub = t_inv_sq * t_inv; // 1/t^3
    double t_inv_fifth = t_inv_cub * t_inv_sq; // 1/t^5
    double t_inv_seventh = t_inv_fifth * t_inv_sq; // 1/t^7
    double t_inv_ninth = t_inv_seventh * t_inv_sq; // 1/t^9

    // Calcul de theta avec les termes optimisés
    return (t / 2.0 * log(t / (2.0 * pi)) - t / 2.0 - pi / 8.0
            + 1.0 / 48.0 * t_inv
            + 7.0 / 5760.0 * t_inv_cub
            + 31.0 / 80640.0 * t_inv_fifth
            + 127.0 / 430080.0 * t_inv_seventh
            + 511.0 / 1216512.0 * t_inv_ninth);
}

/*

Explication des modifications :
Calcul des puissances de z :

Toutes les puissances de z de 1 à 48 sont calculées au début une seule fois.
Chaque terme de la fonction utilise ces valeurs calculées directement, au lieu de recalculer pow(z, n) à chaque appel.
Réduction des appels à pow(z, n) :

La fonction n'appelle plus pow(z, n) à chaque terme individuel, ce qui optimise la performance.
Utilisation des variables pré-calculées :

Chaque puissance de z est stockée dans des variables comme z1, z2, ..., z48, ce qui permet de réduire la redondance dans les calculs.
Condition optimisée :

Les expressions sont maintenues comme dans la version initiale, mais avec les puissances de z déjà calculées, l'exécution devient plus rapide.

*/

double C(int n, double z) {
    // Calcul des puissances de z une seule fois
    double z1 = pow(z, 1.0);  // z^1
    double z2 = pow(z, 2.0);  // z^2
    double z3 = pow(z, 3.0);  // z^3
    double z4 = pow(z, 4.0);  // z^4
    double z5 = pow(z, 5.0);  // z^5
    double z6 = pow(z, 6.0);  // z^6
    double z7 = pow(z, 7.0);  // z^7
    double z8 = pow(z, 8.0);  // z^8
    double z9 = pow(z, 9.0);  // z^9
    double z10 = pow(z, 10.0); // z^10
    double z11 = pow(z, 11.0); // z^11
    double z12 = pow(z, 12.0); // z^12
    double z13 = pow(z, 13.0); // z^13
    double z14 = pow(z, 14.0); // z^14
    double z15 = pow(z, 15.0); // z^15
    double z16 = pow(z, 16.0); // z^16
    double z17 = pow(z, 17.0); // z^17
    double z18 = pow(z, 18.0); // z^18
    double z19 = pow(z, 19.0); // z^19
    double z20 = pow(z, 20.0); // z^20
    double z21 = pow(z, 21.0); // z^21
    double z22 = pow(z, 22.0); // z^22
    double z23 = pow(z, 23.0); // z^23
    double z24 = pow(z, 24.0); // z^24
    double z25 = pow(z, 25.0); // z^25
    double z26 = pow(z, 26.0); // z^26
    double z27 = pow(z, 27.0); // z^27
    double z28 = pow(z, 28.0); // z^28
    double z29 = pow(z, 29.0); // z^29
    double z30 = pow(z, 30.0); // z^30
    double z31 = pow(z, 31.0); // z^31
    double z32 = pow(z, 32.0); // z^32
    double z33 = pow(z, 33.0); // z^33
    double z34 = pow(z, 34.0); // z^34
    double z35 = pow(z, 35.0); // z^35
    double z36 = pow(z, 36.0); // z^36
    double z37 = pow(z, 37.0); // z^37
    double z38 = pow(z, 38.0); // z^38
    double z39 = pow(z, 39.0); // z^39
    double z40 = pow(z, 40.0); // z^40
    double z41 = pow(z, 41.0); // z^41
    double z42 = pow(z, 42.0); // z^42
    double z43 = pow(z, 43.0); // z^43
    double z44 = pow(z, 44.0); // z^44
    double z45 = pow(z, 45.0); // z^45
    double z46 = pow(z, 46.0); // z^46
    double z47 = pow(z, 47.0); // z^47
    double z48 = pow(z, 48.0); // z^48

    if (n == 0)
        return 0.38268343236508977173 * z1
            + 0.43724046807752044936 * z2
            + 0.13237657548034352332 * z4
            - 0.01360502604767418865 * z6
            - 0.01356762197010358089 * z8
            - 0.00162372532314446528 * z10
            + 0.00029705353733379691 * z12
            + 0.00007943300879521470 * z14
            + 0.00000046556124614505 * z16
            - 0.00000143272516309551 * z18
            - 0.00000010354847112313 * z20
            + 0.00000001235792708386 * z22
            + 0.00000000178810838580 * z24
            - 0.00000000003391414390 * z26
            - 0.00000000001632663390 * z28
            - 0.00000000000037851093 * z30
            + 0.00000000000009327423 * z32
            + 0.00000000000000522184 * z34
            - 0.00000000000000033507 * z36
            - 0.00000000000000003412 * z38
            + 0.00000000000000000058 * z40
            + 0.00000000000000000015 * z42;

    else if (n == 1)
        return -0.02682510262837534703 * z1
            + 0.01378477342635185305 * z3
            + 0.03849125048223508223 * z5
            + 0.00987106629906207647 * z7
            - 0.00331075976085840433 * z9
            - 0.00146478085779541508 * z11
            - 0.00001320794062487696 * z13
            + 0.00005922748701847141 * z15
            + 0.00000598024258537345 * z17
            - 0.00000096413224561698 * z19
            - 0.00000018334733722714 * z21
            + 0.00000000446708756272 * z23
            + 0.00000000270963508218 * z25
            + 0.00000000007785288654 * z27
            - 0.00000000002343762601 * z29
            - 0.00000000000158301728 * z31
            + 0.00000000000012119942 * z33
            + 0.00000000000001458378 * z35
            - 0.00000000000000028786 * z37
            - 0.00000000000000008663 * z39
            - 0.00000000000000000084 * z41
            + 0.00000000000000000036 * z43
            + 0.00000000000000000001 * z45;

    else if (n == 2)
        return 0.00518854283029316849 * z1
            + 0.00030946583880634746 * z2
            - 0.01133594107822937338 * z4
            + 0.00223304574195814477 * z6
            + 0.00519663740886233021 * z8
            + 0.00034399144076208337 * z10
            - 0.00059106484274705828 * z12
            - 0.00010229972547935857 * z14
            + 0.00002088839221699276 * z16
            + 0.00000592766549309654 * z18
            - 0.00000016423838362436 * z20
            - 0.00000015161199700941 * z22
            - 0.00000000590780369821 * z24
            + 0.00000000209115148595 * z26
            + 0.00000000017815649583 * z28
            - 0.00000000001616407246 * z30
            - 0.00000000000238069625 * z32
            + 0.00000000000005398265 * z34
            + 0.00000000000001975014 * z36
            + 0.00000000000000023333 * z38
            - 0.00000000000000011188 * z40
            - 0.00000000000000000416 * z42
            + 0.00000000000000000044 * z44
            + 0.00000000000000000003 * z46;

    else if (n == 3)
        return -0.00133971609071945690 * z1
            + 0.00374421513637939370 * z3
            - 0.00133031789193214681 * z5
            - 0.00226546607654717871 * z7
            + 0.00095484999985067304 * z9
            + 0.00060100384589636039 * z11
            - 0.00010128858286776622 * z13
            - 0.00006865733449299826 * z15
            + 0.00000059853667915386 * z17
            + 0.00000333165985123995 * z19
            + 0.00000021919289102435 * z21
            - 0.00000007890884245681 * z23
            - 0.00000000941468508130 * z25
            + 0.00000000095701162109 * z27
            + 0.00000000018763137453 * z29
            - 0.00000000000443783768 * z31
            - 0.00000000000224267385 * z33
            - 0.00000000000003627687 * z35
            + 0.00000000000001763981 * z37
            + 0.00000000000000079608 * z39
            - 0.00000000000000009420 * z41
            - 0.00000000000000000713 * z43
            + 0.00000000000000000033 * z45
            + 0.00000000000000000004 * z47;

    else // n == 4
        return 0.00046483389361763382 * z1
            - 0.00100566073653404708 * z2
            + 0.00024044856573725793 * z4
            + 0.00102830861497023219 * z6
            - 0.00076578610717556442 * z8
            - 0.00020365286803084818 * z10
            + 0.00023212290491068728 * z12
            + 0.00003260214424386520 * z14
            - 0.00002557906251794953 * z16
            - 0.00000410746443891574 * z18
            + 0.00000117811136403713 * z20
            + 0.00000024456561422485 * z22
            - 0.00000002391582476734 * z24
            - 0.00000000750521420704 * z26
            + 0.00000000013312279416 * z28
            + 0.00000000013440626754 * z30
            + 0.00000000000351377004 * z32
            - 0.00000000000151915445 * z34
            - 0.00000000000008915418 * z36
            + 0.00000000000001119589 * z38
            + 0.00000000000000105160 * z40
            - 0.00000000000000005179 * z42
            - 0.00000000000000000807 * z44
            + 0.00000000000000000011 * z46
            + 0.00000000000000000004 * z48;
}

/*

Explication des optimisations :
Pré-calcul de sqrt(t / (2.0 * pi)) :
La racine carrée de t / (2.0 * pi) est calculée une seule fois et réutilisée à la fois pour déterminer N et pour calculer p. Cela évite de recalculer 
la même valeur plusieurs fois dans la fonction.
Optimisation de la boucle ZZ :
Dans la première boucle, les termes log(j) et fmod(tt - t * log(j), 2.0 * pi) sont recalculés à chaque itération. Cela peut être optimisé en calculant 
ces valeurs une seule fois dans l'itération en cours, et en réutilisant ces résultats.
Optimisation de la boucle R :
Dans la deuxième boucle, la valeur de pow(2.0 * pi / t, k * 0.5) est calculée à chaque itération. on pré-calcule la valeur pour k = 0 
(en initialisant factor) et utilisons cette valeur dans les itérations suivantes en multipliant successivement par pow(2.0 * pi / t, 0.5). 
Cela permet d'éviter le recalcul de la même puissance dans chaque itération.
Réduction des appels inutiles :
Les valeurs qui ne dépendent pas de l'index de la boucle, comme sqrt_t_over_2pi et tt, sont calculées une seule fois avant les boucles. 
Cela réduit les appels redondants et améliore la performance globale.

*/

double Z(double t, int n) {
    // Déclaration des variables
    double p;  /* Partie fractionnaire de sqrt(t/(2.0*pi)) */
    double C(int, double);  /* Coefficient de (2*pi/t)^(k*0.5) */
    const double pi = 3.1415926535897932385;
    
    // Calcul de N et p une seule fois
    double sqrt_t_over_2pi = sqrt(t / (2.0 * pi)); // Racine carrée commune
    int N = (int) sqrt_t_over_2pi; // N est entier
    p = sqrt_t_over_2pi - N; // Partie fractionnaire
    
    // Calcul de theta(t) une seule fois
    double tt = theta(t);
    
    // Calcul de ZZ avec optimisation de la première boucle
    double ZZ = 0.0;
    for (int j = 1; j <= N; j++) {
        // Réutilisation de fmod et log de j
        double log_j = log((double)j);
        double angle = fmod(tt - t * log_j, 2.0 * pi);
        ZZ += 1.0 / sqrt((double)j) * cos(angle);
    }
    ZZ = 2.0 * ZZ; // Multiplication finale après la boucle

    // Calcul de R avec optimisation de la deuxième boucle
    double R = 0.0;
    // Pré-calcul de (2.0 * pi / t)^(k * 0.5)
    double factor = pow(2.0 * pi / t, 0.25);  // Calcul de la constante de la première itération
    for (int k = 0; k <= n; k++) {
        // Réutilisation de la puissance
        R += C(k, 2.0 * p - 1.0) * factor;
        factor *= pow(2.0 * pi / t, 0.5); // Met à jour factor pour l'itération suivante
    }

    // Ajout du facteur even(N-1) avant de retourner la valeur finale
    R *= even(N - 1);
    
    // Retourner le résultat final
    return ZZ + R;
}


/*
Explications des optimisations :
Réduction des appels à pow :

pow(k, c1) et pow(deux, un - c1) : Ces puissances sont calculées à chaque itération dans les boucles. on a laissé les calculs où cela est nécessaire, 
mais a évité des recalculs inutiles.
Dans la première boucle, la valeur std::complex<double> p2 = un / pow(k, c1) est réutilisée sans recalculer pow(k, c1).
Optimisation de la boucle de calcul de sum1 et sum2 :

on a conservé la logique de somme alternée pour sum1 et sum2 mais évité des calculs supplémentaires en réutilisant des expressions déjà calculées.
sum2 est calculée dans une boucle supplémentaire où chaque itération est simplifiée en utilisant la valeur pré-calculée de V2[k - N - 1].
Optimisation de V1 et V2 :

Les deux boucles qui remplissent les vecteurs V1 et V2 ont été combinées pour optimiser les calculs.
Les valeurs de V2 sont calculées à partir des valeurs de V1 et stockées dans su, réduisant ainsi le nombre de recalculs.
Utilisation de la constante p1 :

p1 est calculé une seule fois en dehors des boucles, ce qui évite de recalculer des expressions constantes plusieurs fois.
Factorisation et simplification :

Certains calculs dans la fonction ont été simplifiés et les appels complexes ont été rationalisés pour améliorer la lisibilité et la performance du code.
*/


std::complex<double> test_zerod(const double zero, const int N) {
    std::complex<double> un(1.0, 0);  
    std::complex<double> deux(2.0, 0); 
    std::complex<double> c1(0.5, zero); 
    std::complex<double> sum1(0.0, 0.0); 
    std::complex<double> sum2(0.0, 0.0); 
    std::complex<double> p1 = un / (un - pow(deux, un - c1)); // Calcul constant pour la fin

    // Calcul de sum1
    for (int k = 1; k <= N; k++) {
        std::complex<double> p2 = un / pow(k, c1);
        if (k % 2 == 0) {
            sum1 += p2;
        } else {
            sum1 -= p2;
        }
    }

    // Calcul des vecteurs V1 et V2 avec optimisation
    std::vector<double> V1(N);
    std::vector<double> V2(N);
    double coef = 1.0;
    double up = N;
    double dw = 1.0;
    double su = 0.0;

    // Optimisation de la génération de V1 et V2
    for (int k = 0; k < N; k++) {
        coef *= up;
        up -= 1.0;
        coef /= dw;
        dw += 1.0;
        V1[k] = coef;
        su += coef;
    }

    // Calcul des éléments de V2 et de sum2
    for (int k = 0; k < N; k++) {
        V2[k] = su;
        su -= V1[k];
    }

    // Calcul de sum2 en utilisant V2
    for (int k = N + 1; k <= 2 * N; k++) {
        std::complex<double> p2 = un / pow(k, c1);
        double ek = V2[k - N - 1]; // Optimisation de l'indice
        std::complex<double> c3(ek, 0.0);
        std::complex<double> c4 = p2 * c3;
        if (k % 2 == 0) {
            sum2 += c4;
        } else {
            sum2 -= c4;
        }
    }

    // Calcul final du résultat en utilisant p1
    std::complex<double> rez = (sum1 + sum2 / pow(deux, N)) * p1;
    return rez;
}

void test_one_zero(double t)
{
	double RS=Z(t,4);
	std::complex <double> c1=test_zerod(t,10);
	std::complex <double> c2=test_zerod(t,100);
	std::complex <double> c3=test_zerod(t,1000);
	std::cout << std::setprecision(15);
	std::cout << "RS= "<<" "<<RS<<" TEST10= "<< c1 << " TEST100=" << c2 << " TEST1000=" << c3 << std::endl;
	
}

void tests_zeros()
{
	test_one_zero(14.1347251417346937904572519835625);
	test_one_zero(101.3178510057313912287854479402924);
	test_one_zero(1001.3494826377827371221033096531063);
	test_one_zero(10000.0653454145353147502287213889928);

}

/*
	An option to better the performance of Z(t) for large values of t is to simplify the equations
	to validate we present a function that tests the known zeros :  look at https://www.lmfdb.org/zeros/zeta/?limit=10&N=10
	We should obtain 0.0
        no need to test many zeros. In case of a bug the column 2 will show large values instead of values close to 0 like with the original code
	Observe that when t increases the accuracy increases until the limits of the IEEE 754 norm block us, we should work with extended precision
	But here a few digits of precision are enough to count the zeros, only on rare cases the _float128 should be used
	But this limitation only appears very far and with the constraint of resources it won't be possible to reach this region. 
	----------------------------------------------------------------------------------------------------------------------
	value in double			should be 0.0		 value in strings: LMFDB all the digits are corrects
        14.13472514173469463117        -0.00000248590756340983   14.1347251417346937904572519835625
        21.02203963877155601381        -0.00000294582959536882   21.0220396387715549926284795938969
        25.01085758014568938279        -0.00000174024500421144   25.0108575801456887632137909925628
       178.37740777609997167019         0.00000000389177887139   178.3774077760999772858309354141843
       179.91648402025700193008         0.00000000315651035865   179.9164840202569961393400366120511
       182.20707848436646258961         0.00000000214091858131   182.207078484366461915407037226988
 371870901.89642333984375000000         0.00000060389888876036   371870901.8964233245801283081720385309201
 371870902.28132432699203491211        -0.00000083698274928878   371870902.2813243157291041227177012243450
 371870902.52132433652877807617        -0.00000046459056067712   371870902.5213243412580878836297930128983
*/

/*

Explication des changements :
Vérification de fgets :

on a vérifié si la lecture avec fgets a échoué (fgets(...) == NULL).
Si fgets échoue à lire (en raison de la fin du fichier ou d'une erreur), on utilise feof(fi) pour vérifier si la fin du fichier est atteinte et ferror(fi) 
pour vérifier si une erreur de lecture est survenue.
Vérification de la lecture avec sscanf :

Avant de traiter la valeur lue, on a ajouté une vérification que sscanf a effectivement réussi à lire un nombre à virgule flottante (%lf). 
Si sscanf ne retourne pas 1 (le nombre d'éléments correctement analysés), cela signifie qu'il y a un problème avec le format de la ligne.
Taille de la ligne :

on a utilisé sizeof(line) pour lire correctement la taille du tampon de la ligne (qui est de 1024), et non une valeur codée en dur comme 
1000, pour éviter des erreurs d'indexation.

*/
/*
char line[1024];  // Taille de la ligne peut être ajustée à 1024

void test_fileof_zeros(const char *fname)
{
    FILE *fi = fopen(fname, "r");
    assert(fi != NULL);  // Vérification si le fichier a été ouvert avec succès
    
    while (1) {
        double t, RS;
        
        // Lire une ligne du fichier
        if (fgets(line, sizeof(line), fi) == NULL) {
            if (feof(fi)) {
                // Fin du fichier, on quitte la boucle
                break;
            } else if (ferror(fi)) {
                // Une erreur de lecture est survenue
                perror("Erreur de lecture du fichier");
                break;
            }
        }

        // Traitement de la ligne lue
        if (sscanf(line, "%lf", &t) == 1) {  // Vérifier que le sscanf a bien lu un double
            RS = Z(t, 4);
            printf("%30.20lf %30.20lf   %s", t, RS, line);
        }
        // Sinon, la ligne ne contient pas un double valide et est ignorée
    }

    fclose(fi);  // Fermeture du fichier
}
*/


/*

Explications des Optimisations :
Skewing des appels à Z(t, 4) :

Avant de commencer la boucle for, on a calculé la première valeur de zout (Z(LOWER, 4)) et l'a stockée dans la variable zout.
Dans chaque itération de la boucle, on a évité de recalculer la fonction Z(t, 4) deux fois (une pour prev et une pour zout). Au lieu de cela, 
on calcule zout une seule fois pour chaque itération et utilisons la valeur précédente pour la comparaison avec le signe.
Évitement des appels inutiles à Z(t, 4) :

En réutilisant zout et en évitant de recalculer Z(t, 4) deux fois par itération, on réduit le nombre de calculs coûteux de la fonction Z(t, 4).
Optimisation de la gestion des échantillons :

La formule de calcul de NUMSAMPLES est simplifiée en une seule ligne et est utilisée pour déterminer le nombre d'itérations nécessaires pour le calcul de la fonction.
Précision des calculs avec STEP et NUMSAMPLES :

En optimisant le calcul du nombre d'échantillons et de STEP, on réduit les erreurs d'arrondi, ce qui améliore la précision des résultats.
Amélioration de la gestion du temps :

L'appel à dml_micros() est utilisé pour mesurer précisément le temps d'exécution de la boucle et afficher le temps total écoulé.

*/

int main(int argc, char **argv)
{
    double LOWER, UPPER, SAMP;
    const double pi = 3.1415926535897932385;

    // Parsing arguments
    try {
        LOWER = std::atof(argv[1]);
        UPPER = std::atof(argv[2]);
        SAMP = std::atof(argv[3]);
    }
    catch (...) {
        std::cout << argv[0] << " START END SAMPLING" << std::endl;
        return -1;
    }

    // Estimate the number of zeros
    double estimate_zeros = theta(UPPER) / pi;
    printf("I estimate I will find %1.3lf zeros\n", estimate_zeros);

    // Optimizing step size and number of samples
    double STEP = 1.0 / SAMP;
    ui64 NUMSAMPLES = static_cast<ui64>(floor((UPPER - LOWER) * SAMP + 1.0));
    
    // Initializing counters and time
    double prev = 0.0;
    double count = 0.0;
    double t1 = dml_micros();

    // Skewing the loop: Efficient computation of Z(t, 4) by avoiding unnecessary recalculations
    double zout = Z(LOWER, 4);  // Precompute for the first value
    for (double t = LOWER; t <= UPPER; t += STEP) {
        if (t > LOWER) {
            // Check for zero crossing
            if (((zout < 0.0) && (prev > 0.0)) || ((zout > 0.0) && (prev < 0.0))) {
                // printf("%20.6lf  %20.12lf %20.12lf\n", t, prev, zout);
                count++;
            }
        }
        prev = zout;  // Store the current zout for next iteration
        zout = Z(t, 4);  // Precompute zout for the next iteration
    }

    // Final computation and output
    double t2 = dml_micros();
    printf("I found %1.0lf Zeros in %.3lf seconds\n", count, (t2 - t1) / 1000000.0);
    return 0;
}




