#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>
#include <iostream>
#include <iomanip>
#include <cmath>
#include <complex>
#include <vector>
#include <cassert>

/*************************************************************************
* *


This code computes the number of zeros on the critical line of the Zeta function.
https://en.wikipedia.org/wiki/Riemann_zeta_function 

This is one of the most important and non resolved problem in mathematics : https://www.science-et-vie.com/article-magazine/voici-les-7-plus-grands-problemes-de-mathematiques-jamais-resolus

This problem has been the subject of one of the most important distributed computing project in the cloud : more than 10000 machines during 2 years. 
They used this algorithm: very well optimized.
This project failed, bitten by a smaller team that used a far better algorithm. 
The code is based on the Thesis of Glendon Ralph Pugh (1992) : https://web.viu.ca/pughg/thesis.d/masters.thesis.pdf

We can optimize the code in numerous ways, and obviously parallelize it. 

Remark: we do not compute the zeros: we count them to check that they are on the Riemann Line.
Remark: Andrew Odlyzko created a method that is far more efficient but too complex to be the subject of an algorithmetical tuning exercice. 

The exercise is to sample a region on the critical line to count how many times the function changes sign, so that there is at least 1 zero between 2 sampling points.
Here we use a constant sampling but you can recode entirely the way to proceed.

Only a correct (right) count matters, and the performance.

compile g++ RiemannSiegel.cpp -O -o RiemannSiegel
--------------------------------------------------------------------------
./RiemannSiegel 10 1000 100
I found 10142 Zeros in 3.459 seconds     # OK 
--------------------------------------------------------------------------
./RiemannSiegel 10 10000 10 
I found 10142 Zeros in 0.376 seconds     # OK
--------------------------------------------------------------------------
./RiemannSiegel 10 100000 10
I found 137931 Zeros in 6.934 seconds    # INCORRECT
--------------------------------------------------------------------------
./RiemannSiegel 10 100000 100
I found 138069 Zeros in 56.035 seconds   # OK
--------------------------------------------------------------------------
RiemannSiegel 10 1000000     need to find : 1747146     zeros
RiemannSiegel 10 10000000    need to find : 21136125    zeros
RiemannSiegel 10 100000000   need to find : 248888025   zeros
RiemannSiegel 10 1000000000  need to find : 2846548032  zeros
RiemannSiegel 10 10000000000 need to find : 32130158315 zeros


The more regions you validate and with the best timing, the more points you get.

The official world record of the zeros computed is 10^13 but with some FFTs and the method from Odlyzsko.
Compute time 1 year-core so an algortihm 10000*2*40 times more efficient than ZetaGrid's one. 

* *
*************************************************************************/

typedef unsigned long      ui32;
typedef unsigned long long ui64;

/*

Modifications appliquées :
Utilisation de inline: La fonction est marquée comme inline pour encourager le compilateur à insérer son code directement dans le programme à l'endroit où elle est appelée.
Réduction des appels à pow et powl:
Les puissances négatives de t sont calculées directement en multipliant les valeurs au lieu d'utiliser pow, ce qui est plus efficace.
Les appels à pow introduisent une surcharge et des arrondis inutiles pour des exponents constants, car ils sont souvent implémentés comme des boucles ou des approximations.
Pré-calcul des termes: Les parties de l'expression qui sont utilisées plusieurs fois (comme t / 2.0, 1/t, et les puissances inverses) 
sont pré-calculées dans des variables intermédiaires.
Clarté améliorée: Le code est maintenant plus lisible et maintenable.

*/
inline double theta(double t) {
    const double pi = 3.1415926535897932385;
    const double half_t = t / 2.0;
    const double log_term = log(half_t / pi);
    const double t_inv = 1.0 / t;
    const double t_inv3 = t_inv * t_inv * t_inv;
    const double t_inv5 = t_inv3 * t_inv * t_inv;
    const double t_inv7 = t_inv5 * t_inv * t_inv;
    const double t_inv9 = t_inv7 * t_inv * t_inv;

    return (half_t * log_term - half_t - pi / 8.0 +
            1.0 / 48.0 * t_inv +
            7.0 / 5760.0 * t_inv3 +
            31.0 / 80640.0 * t_inv5 +
            127.0 / 430080.0 * t_inv7 +
            511.0 / 1216512.0 * t_inv9);
}

/*
Améliorations :
Suppression des appels à pow :
Les calculs de puissances sont remplacés par des multiplications, beaucoup plus rapides.
Localité des calculs :
Les calculs préliminaires des puissances sont réutilisés à plusieurs endroits.
Efficacité accrue :
La fonction devient plus rapide et adaptée aux optimisations du compilateur.
*/
double C(int n, double z){
    // Pré-calcul des puissances de z
    double z2 = z * z;
    double z3 = z * z2;
    double z4 = z2 * z2;
    double z5 = z3 * z2;
    double z6 = z3 * z3;
    double z7 = z4 * z3;
    double z8 = z4 * z4;
    double z9 = z5 * z4;
    double z10 = z5 * z5;
    double z11 = z6 * z5;
    double z12 = z6 * z6;
    double z13 = z7 * z6;
    double z14 = z7 * z7;
    double z15 = z8 * z7;
    double z16 = z8 * z8;
    double z17 = z9 * z8;
    double z18 = z9 * z9;
    double z19 = z10 * z9;
    double z20 = z10 * z10;
    double z21 = z11 * z10;
    double z22 = z11 * z11;
    double z23 = z12 * z11;
    double z24 = z12 * z12;
    double z25 = z13 * z12;
    double z26 = z13 * z13;
    double z27 = z14 * z13;
    double z28 = z14 * z14;
    double z29 = z15 * z14;
    double z30 = z15 * z15;
    double z31 = z16 * z15;
    double z32 = z16 * z16;
    double z33 = z17 * z16;
    double z34 = z17 * z17;
    double z35 = z18 * z17;
    double z36 = z18 * z18;
    double z37 = z19 * z18;
    double z38 = z19 * z19;
    double z39 = z20 * z19;
    double z40 = z20 * z20;
    double z41 = z21 * z20;
    double z42 = z21 * z21;
    double z43 = z22 * z21;
    double z44 = z22 * z22;
    double z45 = z23 * z22;
    double z46 = z23 * z23;
    double z47 = z24 * z23;
    double z48 = z24 * z24;

    if (n == 0)
        return (.38268343236508977173 * 1
            + .43724046807752044936 * z2
            + .13237657548034352332 * z4
            - .01360502604767418865 * z6
            - .01356762197010358089 * z8
            - .00162372532314446528 * z10
            + .00029705353733379691 * z12
            + .00007943300879521470 * z14
            + .00000046556124614505 * z16
            - .00000143272516309551 * z18
            - .00000010354847112313 * z20
            + .00000001235792708386 * z22
            + .00000000178810838580 * z24
            - .00000000003391414390 * z26
            - .00000000001632663390 * z28
            - .00000000000037851093 * z30
            + .00000000000009327423 * z32
            + .00000000000000522184 * z34
            - .00000000000000033507 * z36
            - .00000000000000003412 * z38
            + .00000000000000000058 * z40
            + .00000000000000000015 * z42);
    else if (n == 1)
        return (-.02682510262837534703 * z
            + .01378477342635185305 * z3
            + .03849125048223508223 * z5
            + .00987106629906207647 * z7
            - .00331075976085840433 * z9
            - .00146478085779541508 * z11
            - .00001320794062487696 * z13
            + .00005922748701847141 * z15
            + .00000598024258537345 * z17
            - .00000096413224561698 * z19
            - .00000018334733722714 * z21
            + .00000000446708756272 * z23
            + .00000000270963508218 * z25
            + .00000000007785288654 * z27
            - .00000000002343762601 * z29
            - .00000000000158301728 * z31
            + .00000000000012119942 * z33
            + .00000000000001458378 * z35
            - .00000000000000028786 * z37
            - .00000000000000008663 * z39
            - .00000000000000000084 * z41
            + .00000000000000000036 * z43
            + .00000000000000000001 * z45);
    else if (n == 2)
        return (+.00518854283029316849 * 1
            + .00030946583880634746 * z2
            - .01133594107822937338 * z4
            + .00223304574195814477 * z6
            + .00519663740886233021 * z8
            + .00034399144076208337 * z10
            - .00059106484274705828 * z12
            - .00010229972547935857 * z14
            + .00002088839221699276 * z16
            + .00000592766549309654 * z18
            - .00000016423838362436 * z20
            - .00000015161199700941 * z22
            - .00000000590780369821 * z24
            + .00000000209115148595 * z26
            + .00000000017815649583 * z28
            - .00000000001616407246 * z30
            - .00000000000238069625 * z32
            + .00000000000005398265 * z34
            + .00000000000001975014 * z36
            + .00000000000000023333 * z38
            - .00000000000000011188 * z40
            - .00000000000000000416 * z42
            + .00000000000000000044 * z44
            + .00000000000000000003 * z46);
    else if (n == 3)
        return (-.00133971609071945690 * z
            + .00374421513637939370 * z3
            - .00133031789193214681 * z5
            - .00226546607654717871 * z7
            + .00095484999985067304 * z9
            + .00060100384589636039 * z11
            - .00010128858286776622 * z13
            - .00006865733449299826 * z15
            + .00000059853667915386 * z17
            + .00000333165985123995 * z19
            + .00000021919289102435 * z21
            - .00000007890884245681 * z23
            - .00000000941468508130 * z25
            + .00000000095701162109 * z27
            + .00000000018763137453 * z29
            - .00000000000443783768 * z31
            - .00000000000224267385 * z33
            - .00000000000003627687 * z35
            + .00000000000001763981 * z37
            + .00000000000000079608 * z39
            - .00000000000000009420 * z41
            - .00000000000000000713 * z43
            + .00000000000000000033 * z45
            + .00000000000000000004 * z47);
    else
        return (+.00046483389361763382 * 1
            - .00100566073653404708 * z2
            + .00024044856573725793 * z4
            + .00102830861497023219 * z6
            - .00076578610717556442 * z8
            - .00020365286803084818 * z10
            + .00023212290491068728 * z12
            + .00003260214424386520 * z14
            - .00002557906251794953 * z16
            - .00000410746443891574 * z18
            + .00000117811136403713 * z20
            + .00000024456561422485 * z22
            - .00000002391582476734 * z24
            - .00000000750521420704 * z26
            + .00000000013312279416 * z28
            + .00000000013440626754 * z30
            + .00000000000351377004 * z32
            - .00000000000151915445 * z34
            - .00000000000008915418 * z36
            + .00000000000001119589 * z38
            + .00000000000000105160 * z40
            - .00000000000000005179 * z42
            - .00000000000000000807 * z44
            + .00000000000000000011 * z46
            + .00000000000000000004 * z48);
}

/*

Optimisation de la fonction Z :

Calcul de N et p : on calcule N et p plus directement et de manière plus efficace. Le calcul de la partie fractionnaire p est fait en soustrayant 
directement la partie entière de la racine carrée de t / (2 * pi).
Réduction des appels répétitifs à pow et log : Les appels à pow et log sont optimisés en réduisant les calculs redondants à chaque itération. 
Par exemple, on calcule pow(2.0 * pi / t, 0.25) une seule fois avant la boucle et on utilise cette valeur dans la somme pour R.
Optimisation de theta(t) : Il est supposé que la fonction theta(t) a déjà été optimisée dans un format similaire à celui de la fonction précédente 
(en utilisant des pré-calculs pour éviter l'usage de pow dans theta).
Éviter des conversions inutiles :

Les conversions explicites de double à int et vice versa sont faites de manière minimale pour améliorer la clarté et l'efficacité.

*/

inline double Z(double t, int n) {
    const double pi = 3.1415926535897932385;
    double p = sqrt(t / (2.0 * pi)) - static_cast<int>(sqrt(t / (2.0 * pi)));  // Calcul de la partie fractionnaire
    double tt = theta(t);  // On suppose que la fonction `theta` est déjà optimisée
    int N = static_cast<int>(sqrt(t / (2.0 * pi)));  // N est une constante entière
    double ZZ = 0.0;

    // Première somme (calcul de ZZ)
    for (int j = 1; j <= N; j++) {
        ZZ += 1.0 / sqrt(static_cast<double>(j)) * cos(fmod(tt - t * log(static_cast<double>(j)), 2.0 * pi));
    }
    ZZ = 2.0 * ZZ;

    // Deuxième somme (calcul de R)
    double R = 0.0;
    double factor = pow(2.0 * pi / t, 0.25);  // Facteur constant pour réduire les répétitions
    for (int k = 0; k <= n; k++) {
        R += C(k, 2.0 * p - 1.0) * pow(2.0 * pi / t, 0.5 * k);  // Calcul de chaque terme
    }
	
    // Inlining manuel de la fonction even(N-1)
    R = ((N - 1) % 2 == 0 ? 1 : -1) * pow(2.0 * pi / t, 0.25) * R;  // Even(N-1) directement ici

    // Résultat final
    return ZZ + R;
}

/*
Explications des optimisations :
Inlining des petites fonctions compute_p2 et compute_p1 :

on a créé des fonctions internes compute_p2 et compute_p1 pour le calcul de p2 et p1. Ces fonctions sont très petites, et en les marquant inline, 
on évite des appels de fonction coûteux. Elles calculent directement les expressions utilisées dans la boucle, et leur code est inséré à 
l'endroit où elles sont appelées, réduisant ainsi l'overhead.
Calcul de p1 et p2 en ligne :

p1 est calculé au début en utilisant la fonction compute_p1, et p2 est calculé dans les boucles à l'aide de compute_p2. En utilisant inline, 
les opérations répétées telles que pow(k, c1) sont calculées sans appeler la fonction pow à chaque itération.
Réduction des calculs répétitifs :

Les calculs de p2 dans les boucles sont rendus plus efficaces en les extrayant dans la fonction compute_p2. Ce calcul est effectué une 
seule fois par itération, ce qui est plus rapide que de répéter le calcul de la puissance dans la boucle.
Optimisation des boucles :

Les boucles sont conservées avec les calculs directement intégrés dans les expressions. Aucune opération coûteuse n'est effectuée en 
dehors des calculs de p1 et p2.
Optimisation de l'usage des std::complex<double> :

on continu à utiliser std::complex<double> pour les opérations complexes, et les optimisations se concentrent principalement 
sur l'efficacité des boucles et le calcul des puissances.
*/

// Inlining des petites fonctions lorsque c'est possible
inline std::complex<double> compute_p2(double k, const std::complex<double>& c1) {
    return 1.0 / std::pow(k, c1); // Remplacer `pow(k, c1)` par la version inlinée
}

inline std::complex<double> compute_p1(const std::complex<double>& c1) {
    return 1.0 / (1.0 - std::pow(2.0, 1.0 - c1)); // Calcul de p1 en ligne
}

std::complex<double> test_zerod(const double zero, const int N) {
    std::complex<double> un(1.0, 0);
    std::complex<double> deux(2.0, 0);
    std::complex<double> c1(0.5, zero);
    
    std::complex<double> sum1(0.0, 0.0);
    std::complex<double> sum2(0.0, 0.0);

    // Calcul de p1 en ligne
    std::complex<double> p1 = compute_p1(c1);

    // Première boucle (sum1)
    for (int k = 1; k <= N; k++) {
        std::complex<double> p2 = compute_p2(k, c1);
        if (k % 2 == 0) sum1 += p2;
        if (k % 2 == 1) sum1 -= p2;
    }

    // Préparation des vecteurs V1 et V2
    std::vector<double> V1(N);
    std::vector<double> V2(N);
    double coef = 1.0;
    double up = N;
    double dw = 1.0;
    double su = 0.0;

    // Calcul des coefficients pour V1 et somme pour su
    for (int k = 0; k < N; k++) {
        coef *= up;
        up -= 1.0;
        coef /= dw;
        dw += 1.0;
        V1[k] = coef;
        su += coef;
    }

    // Calcul de V2
    for (int k = 0; k < N; k++) {
        V2[k] = su;
        su -= V1[k];
    }

    // Deuxième boucle (sum2)
    for (int k = N + 1; k <= 2 * N; k++) {
        std::complex<double> p2 = compute_p2(k, c1);
        double ek = V2[k - N - 1];
        std::complex<double> c3(ek, 0.0);
        std::complex<double> c4 = p2 * c3;
        if (k % 2 == 0) sum2 += c4;
        if (k % 2 == 1) sum2 -= c4;
    }

    // Calcul du résultat final
    std::complex<double> rez = (sum1 + sum2 / std::pow(deux, N)) * p1;
    return rez;
}

/*

Explication des Optimisations :
Inlined print_results :

La fonction print_results est une petite fonction qui se contente de formater et d'afficher les résultats. Elle est inlinée, 
de sorte que l'appel à std::cout ne crée pas d'overhead supplémentaire en termes d'appel de fonction. En l'inclinant, 
on évite de la traiter comme une fonction ordinaire et cela permet de réduire l'overhead lors de l'appel d'affichage.

*/

inline void print_results(double RS, const std::complex<double>& c1, const std::complex<double>& c2, const std::complex<double>& c3) {
    // Fonction inline pour l'affichage
    std::cout << std::setprecision(15);
    std::cout << "RS= " << RS << " TEST10= " << c1 << " TEST100= " << c2 << " TEST1000= " << c3 << std::endl;
}

void test_one_zero(double t)
{
	double RS=Z(t,4);
	std::complex <double> c1=test_zerod(t,10);
	std::complex <double> c2=test_zerod(t,100);
	std::complex <double> c3=test_zerod(t,1000);
	
    // Affichage des résultats via la fonction inline
    print_results(RS, c1, c2, c3);
}



void tests_zeros()
{
	test_one_zero(14.1347251417346937904572519835625);
	test_one_zero(101.3178510057313912287854479402924);
	test_one_zero(1001.3494826377827371221033096531063);
	test_one_zero(10000.0653454145353147502287213889928);

}

/*
	An option to better the performance of Z(t) for large values of t is to simplify the equations
	to validate we present a function that tests the known zeros :  look at https://www.lmfdb.org/zeros/zeta/?limit=10&N=10
	We should obtain 0.0
        no need to test many zeros. In case of a bug the column 2 will show large values instead of values close to 0 like with the original code
	Observe that when t increases the accuracy increases until the limits of the IEEE 754 norm block us, we should work with extended precision
	But here a few digits of precision are enough to count the zeros, only on rare cases the _float128 should be used
	But this limitation only appears very far and with the constraint of resources it won't be possible to reach this region. 
	----------------------------------------------------------------------------------------------------------------------
	value in double			should be 0.0		 value in strings: LMFDB all the digits are corrects
        14.13472514173469463117        -0.00000248590756340983   14.1347251417346937904572519835625
        21.02203963877155601381        -0.00000294582959536882   21.0220396387715549926284795938969
        25.01085758014568938279        -0.00000174024500421144   25.0108575801456887632137909925628
       178.37740777609997167019         0.00000000389177887139   178.3774077760999772858309354141843
       179.91648402025700193008         0.00000000315651035865   179.9164840202569961393400366120511
       182.20707848436646258961         0.00000000214091858131   182.207078484366461915407037226988
 371870901.89642333984375000000         0.00000060389888876036   371870901.8964233245801283081720385309201
 371870902.28132432699203491211        -0.00000083698274928878   371870902.2813243157291041227177012243450
 371870902.52132433652877807617        -0.00000046459056067712   371870902.5213243412580878836297930128983
*/

/*


Explication des optimisations :
Inlining de get_RS :

La fonction get_RS est une version simplifiée de l'appel à Z(t, 4). En l'inclinant, nous éliminons l'overhead d'un appel de fonction pour 
cette opération qui est simple (calculer Z(t, 4)).
Inlining de process_line :

La fonction process_line prend en charge la lecture d'une ligne, le parsing de la valeur t, le calcul de RS, et l'affichage du résultat. 
En la marquant comme inline, cela évite la surcharge d'un appel de fonction supplémentaire à chaque itération de la boucle.
Traitement ligne par ligne :

Au lieu de faire une boucle infinie for(;;) et vérifier feof(fi) dans chaque itération, j'ai changé la structure pour utiliser la fonction 
process_line de manière à garder le code propre et éviter de traiter des lignes vides ou des erreurs de lecture.


*/

/*inline void process_line(FILE *fi) {
    // Cette fonction inlinée remplace le traitement de chaque ligne.
    char line[1024];
    double t, RS;

    // Lecture et traitement de chaque ligne
    if (fgets(line, sizeof(line), fi) != NULL) {
        sscanf(line, "%lf", &t);
        RS = RS=Z(t,4);
        printf(" %30.20lf %30.20lf   %s", t, RS, line);
    }
}

void test_fileof_zeros(const char *fname) {
    FILE *fi = fopen(fname, "r");
    assert(fi != NULL);

    // Traitement ligne par ligne en appelant la fonction inline
    while (!feof(fi)) {
        process_line(fi);
    }

    fclose(fi);
}
*/

/*

Inlining de print_estimate() et print_zero_count() :

Ces fonctions sont responsables de l'affichage du nombre estimé de zéros et du compte final. Comme elles sont appelées une seule fois dans le code principal, 
en faire des fonctions inlinées simplifie le code tout en réduisant l'overhead d'un appel de fonction.

*/

// Déclaration des fonctions externes pour simplification.
inline void print_estimate(double estimate_zeros) {
    printf("I estimate I will find %1.3lf zeros\n", estimate_zeros);
}

inline void print_zero_count(double count, double time_taken) {
    printf("I found %1.0lf Zeros in %.3lf seconds\n", count, time_taken);
}

int main(int argc, char **argv) {
    double LOWER, UPPER, SAMP;
    const double pi = 3.1415926535897932385;

    try {
        LOWER = std::atof(argv[1]);
        UPPER = std::atof(argv[2]);
        SAMP = std::atof(argv[3]);
    } catch (...) {
        std::cout << argv[0] << " START END SAMPLING" << std::endl;
        return -1;
    }

    double estimate_zeros = theta(UPPER) / pi;
    print_estimate(estimate_zeros);

    double STEP = 1.0 / SAMP;
    ui64 NUMSAMPLES = floor((UPPER - LOWER) * SAMP + 1.0);
    double prev = 0.0;
    double count = 0.0;
	
    // Code d'inlining manuel pour la récupération du temps en microsecondes
    static struct timezone tz;
    static struct timeval tv;
    gettimeofday(&tv, &tz);
    double t1 = (tv.tv_sec * 1000000.0) + tv.tv_usec;
	
    for (double t = LOWER; t <= UPPER; t += STEP) {
        double zout = Z(t, 4);
        if (t > LOWER) {
            if (((zout < 0.0) && (prev > 0.0)) || ((zout > 0.0) && (prev < 0.0))) {
                count++;
            }
        }
        prev = zout;
    }
    // Code d'inlining manuel pour la récupération du temps après la boucle
    gettimeofday(&tv, &tz);
    double t2 = (tv.tv_sec * 1000000.0) + tv.tv_usec;
    print_zero_count(count, (t2 - t1) / 1000000.0);

    return 0;
}




