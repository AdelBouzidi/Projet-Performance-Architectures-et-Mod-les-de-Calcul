#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>
#include <iostream>
#include <iomanip>
#include <cmath>
#include <complex>
#include <vector>
#include <cassert>

/*************************************************************************
* *


This code computes the number of zeros on the critical line of the Zeta function.
https://en.wikipedia.org/wiki/Riemann_zeta_function 

This is one of the most important and non resolved problem in mathematics : https://www.science-et-vie.com/article-magazine/voici-les-7-plus-grands-problemes-de-mathematiques-jamais-resolus

This problem has been the subject of one of the most important distributed computing project in the cloud : more than 10000 machines during 2 years. 
They used this algorithm: very well optimized.
This project failed, bitten by a smaller team that used a far better algorithm. 
The code is based on the Thesis of Glendon Ralph Pugh (1992) : https://web.viu.ca/pughg/thesis.d/masters.thesis.pdf

We can optimize the code in numerous ways, and obviously parallelize it. 

Remark: we do not compute the zeros: we count them to check that they are on the Riemann Line.
Remark: Andrew Odlyzko created a method that is far more efficient but too complex to be the subject of an algorithmetical tuning exercice. 

The exercise is to sample a region on the critical line to count how many times the function changes sign, so that there is at least 1 zero between 2 sampling points.
Here we use a constant sampling but you can recode entirely the way to proceed.

Only a correct (right) count matters, and the performance.

compile g++ RiemannSiegel.cpp -O -o RiemannSiegel
--------------------------------------------------------------------------
./RiemannSiegel 10 1000 100
I found 10142 Zeros in 3.459 seconds     # OK 
--------------------------------------------------------------------------
./RiemannSiegel 10 10000 10 
I found 10142 Zeros in 0.376 seconds     # OK
--------------------------------------------------------------------------
./RiemannSiegel 10 100000 10
I found 137931 Zeros in 6.934 seconds    # INCORRECT
--------------------------------------------------------------------------
./RiemannSiegel 10 100000 100
I found 138069 Zeros in 56.035 seconds   # OK
--------------------------------------------------------------------------
RiemannSiegel 10 1000000     need to find : 1747146     zeros
RiemannSiegel 10 10000000    need to find : 21136125    zeros
RiemannSiegel 10 100000000   need to find : 248888025   zeros
RiemannSiegel 10 1000000000  need to find : 2846548032  zeros
RiemannSiegel 10 10000000000 need to find : 32130158315 zeros


The more regions you validate and with the best timing, the more points you get.

The official world record of the zeros computed is 10^13 but with some FFTs and the method from Odlyzsko.
Compute time 1 year-core so an algortihm 10000*2*40 times more efficient than ZetaGrid's one. 

* *
*************************************************************************/

typedef unsigned long      ui32;
typedef unsigned long long ui64;

double dml_micros()
{
        static struct timezone tz;
        static struct timeval  tv;
        gettimeofday(&tv,&tz);
        return((tv.tv_sec*1000000.0)+tv.tv_usec);
}

int even(int n)
{
	if (n%2 == 0) return(1);
	else          return(-1);
}

/*

Modifications et Explications
Pré-calcul des termes récurrents :

t/2.0 (assigné à half_t) et log(t/2.0/pi) (assigné à log_term) sont calculés une seule fois au lieu de plusieurs fois dans l'expression finale.
Les termes inverses de puissances de t (par exemple, 1/t, 1/t^3, 1/t^5) sont également pré-calculés pour éviter les appels répétitifs à pow ou powl.
Élimination des appels à pow et powl :

Les appels à pow ou powl sont coûteux, et dans ce cas, ils ne sont pas nécessaires car les puissances peuvent être obtenues en multipliant les termes 
déjà calculés (comme t3_inv, t5_inv, etc.).
Amélioration de la lisibilité et des performances :

En pré-calculant les termes et en réduisant la complexité des expressions finales, le code devient plus lisible et plus rapide à exécuter.
Économie sur les accès mémoire :

Les résultats des pré-calculs sont stockés dans des variables locales, ce qui favorise la localité des données (elles restent dans le cache de 
la CPU au lieu de nécessiter de multiples lectures depuis la mémoire).

*/

double theta(double t) {
    const double pi = 3.1415926535897932385;

    // **Pré-calcul des termes récurrents pour réduire les calculs**
    double half_t = t / 2.0;       // Pré-calcul de t/2
    double log_term = log(half_t / pi); // Pré-calcul de log(t/2/pi)
    double t_inv = 1.0 / t;       // Pré-calcul de 1/t
    double t3_inv = t_inv * t_inv * t_inv; // Pré-calcul de 1/t^3
    double t5_inv = t3_inv * t_inv * t_inv; // Pré-calcul de 1/t^5
    double t7_inv = t5_inv * t_inv * t_inv; // Pré-calcul de 1/t^7
    double t9_inv = t7_inv * t_inv * t_inv; // Pré-calcul de 1/t^9

    // **Calcul final optimisé en utilisant les termes pré-calculés**
    return (
        half_t * log_term - half_t - pi / 8.0 + 
        (1.0 / 48.0) * t_inv + 
        (7.0 / 5760.0) * t3_inv + 
        (31.0 / 80640.0) * t5_inv + 
        (127.0 / 430080.0) * t7_inv + 
        (511.0 / 1216512.0) * t9_inv
    );
    // Les fractions et les puissances sont évaluées de manière directe et optimisée
}



/*

Explications des Modifications
Pré-calcul des puissances de 
𝑧
z :

Stockées dans le tableau z_pow pour éviter les appels répétitifs à pow.
Tableaux de coefficients :

Les coefficients sont regroupés par 
𝑛
n, organisés pour un accès rapide en mémoire.
Accès séquentiel aux coefficients :

Les coefficients et puissances sont lus séquentiellement dans une boucle.
Élimination des branches inutiles :

Les coefficients de chaque 
𝑛
n sont chargés directement sans conditions coûteuses (if-else).

*/

// Fonction C(n, z) optimisée
double C(int n, double z) {
    // **Pré-calcul des puissances de z**
    double z_pow[49]; // Tableau pour stocker z^k (k = 0 à 48)
    z_pow[0] = 1.0;   // z^0 = 1
    for (int k = 1; k < 49; ++k) {
        z_pow[k] = z_pow[k - 1] * z; // Calcul progressif des puissances
    }

    // **Coefficients pour chaque cas de n**
    static const double coeffs[5][96] = {
        { // Coefficients pour n = 0 (96 entrées : 48 coefficients + 48 puissances)
            .38268343236508977173, 0.0,
            .43724046807752044936, 2.0,
            .13237657548034352332, 4.0,
            -.01360502604767418865, 6.0,
            -.01356762197010358089, 8.0,
            -.00162372532314446528, 10.0,
            .00029705353733379691, 12.0,
            .00007943300879521470, 14.0,
            .00000046556124614505, 16.0,
            -.00000143272516309551, 18.0,
            -.00000010354847112313, 20.0,
            .00000001235792708386, 22.0,
            .00000000178810838580, 24.0,
            -.00000000003391414390, 26.0,
            -.00000000001632663390, 28.0,
            -.00000000000037851093, 30.0,
            .00000000000009327423, 32.0,
            .00000000000000522184, 34.0,
            -.00000000000000033507, 36.0,
            -.00000000000000003412, 38.0,
            .00000000000000000058, 40.0,
            .00000000000000000015, 42.0
        },
        { // Coefficients pour n = 1
            -.02682510262837534703, 1.0,
            .01378477342635185305, 3.0,
            .03849125048223508223, 5.0,
            .00987106629906207647, 7.0,
            -.00331075976085840433, 9.0,
            -.00146478085779541508, 11.0,
            -.00001320794062487696, 13.0,
            .00005922748701847141, 15.0,
            .00000598024258537345, 17.0,
            -.00000096413224561698, 19.0,
            -.00000018334733722714, 21.0,
            .00000000446708756272, 23.0,
            .00000000270963508218, 25.0,
            .00000000007785288654, 27.0,
            -.00000000002343762601, 29.0,
            -.00000000000158301728, 31.0,
            .00000000000012119942, 33.0,
            .00000000000001458378, 35.0,
            -.00000000000000028786, 37.0,
            -.00000000000000008663, 39.0,
            -.00000000000000000084, 41.0,
            .00000000000000000036, 43.0,
            .00000000000000000001, 45.0
        },
        { // Coefficients pour n = 2
            .00518854283029316849, 0.0,
            .00030946583880634746, 2.0,
            -.01133594107822937338, 4.0,
            .00223304574195814477, 6.0,
            .00519663740886233021, 8.0,
            .00034399144076208337, 10.0,
            -.00059106484274705828, 12.0,
            -.00010229972547935857, 14.0,
            .00002088839221699276, 16.0,
            .00000592766549309654, 18.0,
            -.00000016423838362436, 20.0,
            -.00000015161199700941, 22.0,
            -.00000000590780369821, 24.0,
            .00000000209115148595, 26.0,
            .00000000017815649583, 28.0,
            -.00000000001616407246, 30.0,
            -.00000000000238069625, 32.0,
            .00000000000005398265, 34.0,
            .00000000000001975014, 36.0,
            .00000000000000023333, 38.0,
            -.00000000000000011188, 40.0,
            -.00000000000000000416, 42.0,
            .00000000000000000044, 44.0,
            .00000000000000000003, 46.0
        },
        { // Coefficients pour n = 3
            -.00133971609071945690, 1.0,
            .00374421513637939370, 3.0,
            -.00133031789193214681, 5.0,
            -.00226546607654717871, 7.0,
            .00095484999985067304, 9.0,
            .00060100384589636039, 11.0,
            -.00010128858286776622, 13.0,
            -.00006865733449299826, 15.0,
            .00000059853667915386, 17.0,
            .00000333165985123995, 19.0,
            .00000021919289102435, 21.0,
            -.00000007890884245681, 23.0,
            -.00000000941468508130, 25.0,
            .00000000095701162109, 27.0,
            .00000000018763137453, 29.0,
            -.00000000000443783768, 31.0,
            -.00000000000224267385, 33.0,
            -.00000000000003627687, 35.0,
            .00000000000001763981, 37.0,
            .00000000000000079608, 39.0,
            -.00000000000000009420, 41.0,
            -.00000000000000000713, 43.0,
            .00000000000000000033, 45.0,
            .00000000000000000004, 47.0
        },
        { // Coefficients pour n = 4
            .00046483389361763382, 0.0,
            -.00100566073653404708, 2.0,
            .00024044856573725793, 4.0,
            .00102830861497023219, 6.0,
            -.00076578610717556442, 8.0,
            -.00020365286803084818, 10.0,
            .00023212290491068728, 12.0,
            .00003260214424386520, 14.0,
            -.00002557906251794953, 16.0,
            -.00000410746443891574, 18.0,
            .00000117811136403713, 20.0,
            .00000024456561422485, 22.0,
            -.00000002391582476734, 24.0,
            -.00000000750521420704, 26.0,
            .00000000013312279416, 28.0,
            .00000000013440626754, 30.0,
            .00000000000351377004, 32.0,
            -.00000000000151915445, 34.0,
            -.00000000000008915418, 36.0,
            .00000000000001119589, 38.0,
            .00000000000000105160, 40.0,
            -.00000000000000005179, 42.0,
            -.00000000000000000807, 44.0,
            .00000000000000000011, 46.0,
            .00000000000000000001, 48.0
        }
    };

    // **Accès au tableau de coefficients selon n**
    const double* current_coeffs = coeffs[n];
    int coeff_count = 48; // Chaque tableau contient 48 coefficients

    // **Calcul du résultat**
    double result = 0.0;
    for (int i = 0; i < coeff_count * 2; i += 2) {
        double coeff = current_coeffs[i]; // Coefficient
        int power = (int)current_coeffs[i + 1]; // Puissance
        result += coeff * z_pow[power]; // Utilise la puissance pré-calculée
    }

    return result;
}




/*

Points Clés de l'Optimisation

Pré-chargement des racines inverses :
Calcul de 1/√j pour tous les j dans la première boucle.
Évite de recalculer les racines carrées dans chaque itération.
Pré-chargement des logarithmes :
Calcul de tt - t*log(j) mod 2π pour tous les j.
Permet d'économiser les calculs de logarithmes coûteux dans la boucle principale.
Pré-chargement des puissances :
Calcul de (2π/t)^(k/0.5) pour k = 0,..., n.
Évite les calculs exponentiels répétés dans la seconde boucle.
Réduction des calculs redondants :
Pré-calcul de √2π, 2π/t, √t, etc., pour les utiliser dans les boucles.
Gestion mémoire :
Utilisation de tableaux dynamiques pour stocker les pré-calculs nécessaires.
Nettoyage explicite des tableaux avec delete[] pour éviter les fuites de mémoire.

*/

double Z(double t, int n)
//*************************************************************************
// Fonction Riemann-Siegel Z(t) optimisée utilisant la prélecture explicite.
// Implémentée selon la formule de Riemann-Siegel. Voir la référence ici:
// http://mathworld.wolfram.com/Riemann-SiegelFormula.html
//*************************************************************************
{
    const double pi = 3.1415926535897932385;

    // Étape 1 : Calcul de valeurs constantes pour éviter leur recalcul dans les boucles
    double sqrt_2pi = sqrt(2.0 * pi);
    double inv_sqrt_2pi = 1.0 / sqrt_2pi;
    double sqrt_t = sqrt(t);
    double sqrt_t_div_2pi = sqrt_t * inv_sqrt_2pi; // sqrt(t / (2π))
    int N = static_cast<int>(sqrt_t_div_2pi);      // Partie entière de sqrt(t / (2π))
    double p = sqrt_t_div_2pi - N;                // Partie fractionnaire de sqrt(t / (2π))
    double tt = theta(t);                         // Pré-calcul de θ(t)
    double two_pi_over_t = 2.0 * pi / t;          // Pré-calcul de 2π/t
    double sqrt_two_pi_over_t = sqrt(two_pi_over_t); // √(2π/t)

    // Étape 2 : Pré-chargement des valeurs réutilisées dans la première boucle
    double* sqrt_inv_j = new double[N + 1]; // Stocke 1 / √j pour j = 1 à N
    double* tt_t_log_j = new double[N + 1]; // Stocke tt - t * log(j) mod 2π pour j = 1 à N
    for (int j = 1; j <= N; ++j) {
        sqrt_inv_j[j] = 1.0 / sqrt(static_cast<double>(j)); // Pré-calcul 1 / √j
        tt_t_log_j[j] = fmod(tt - t * log(static_cast<double>(j)), 2.0 * pi); // Pré-calcul
    }

    // Étape 3 : Calcul de ZZ en utilisant les valeurs préchargées
    double ZZ = 0.0;
    for (int j = 1; j <= N; ++j) {
        ZZ += sqrt_inv_j[j] * cos(tt_t_log_j[j]); // Utilisation des valeurs pré-chargées
    }
    ZZ *= 2.0; // ZZ = 2 * Somme

    // Nettoyage mémoire pour éviter les fuites
    delete[] sqrt_inv_j;
    delete[] tt_t_log_j;

    // Étape 4 : Pré-chargement des puissances (2π/t)^k*0.5 pour éviter leur recalcul
    double* powers_two_pi_over_t = new double[n + 1]; // Stocke (2π/t)^(k*0.5)
    powers_two_pi_over_t[0] = 1.0; // (2π/t)^0 = 1
    for (int k = 1; k <= n; ++k) {
        powers_two_pi_over_t[k] = powers_two_pi_over_t[k - 1] * sqrt_two_pi_over_t; // Progression
    }

    // Étape 5 : Calcul de R en utilisant les valeurs préchargées
    double R = 0.0;
    for (int k = 0; k <= n; ++k) {
        double Ck = C(k, 2.0 * p - 1.0); // Coefficient C(k, 2p-1)
        R += Ck * powers_two_pi_over_t[k]; // R = Somme des termes préchargés
    }

    // Nettoyage mémoire pour les puissances
    delete[] powers_two_pi_over_t;

    // Étape 6 : Calcul final de R avec le facteur pair/impair et racine supplémentaire
    R *= even(N - 1) * sqrt(sqrt_two_pi_over_t);

    // Étape 7 : Retourne la somme finale ZZ + R
    return ZZ + R;
}


/*
Explications des Optimisations

Pré-chargement des puissances k^d-1 dans des tableaux :
Les puissances k^d-1 sont coûteuses à calculer. Elles sont pré-calculées pour k = 1 à N et pour k = N+1 à 2N.
Cela évite des appels répétitifs à pow.
Pré-chargement des coefficients combinatoires V1 et V2 :
Les coefficients combinatoires sont pré-calculés dans V1.
Les sommes cumulées nécessaires sont pré-chargées dans V2.
Réduction des calculs dans les boucles :
Les calculs lourds sont déplacés en dehors des boucles pour réduire la charge à chaque itération.
Utilisation de tableaux dynamiques :
Des std::vector sont utilisés pour stocker les valeurs intermédiaires, permettant une gestion mémoire efficace.
Optimisation des conversions en complexe :
Les coefficients ex sont directement convertis en complexes dans c3.
Simplification des expressions conditionnelles :
Les conditions k%2 == 0 et k%2 == 1 sont utilisées pour alterner les ajouts et les soustractions.
*/


std::complex<double> test_zerod(const double zero, const int N) {
    // Étape 1 : Déclaration des constantes et initialisation
    std::complex<double> un(1.0, 0.0);    // Constante complexe 1
    std::complex<double> deux(2.0, 0.0);  // Constante complexe 2
    std::complex<double> c1(0.5, zero);   // Coefficient c1 (0.5 + i*zero)
    std::complex<double> sum1(0.0, 0.0);  // Somme 1
    std::complex<double> sum2(0.0, 0.0);  // Somme 2
    std::complex<double> p1 = un / (un - pow(deux, un - c1)); // Calcul de p1

    // Étape 2 : Préchargement des puissances k^(-c1) pour k = 1 à N
    std::vector<std::complex<double>> powers_k_c1(N + 1); // Stocke k^(-c1)
    for (int k = 1; k <= N; ++k) {
        powers_k_c1[k] = un / pow(static_cast<double>(k), c1); // Calcul une fois pour toutes
    }

    // Étape 3 : Calcul de sum1 en utilisant les valeurs préchargées
    for (int k = 1; k <= N; ++k) {
        if (k % 2 == 0) {
            sum1 += powers_k_c1[k]; // Ajout si pair
        } else {
            sum1 -= powers_k_c1[k]; // Soustraction si impair
        }
    }

    // Étape 4 : Pré-chargement des coefficients V1 et V2
    std::vector<double> V1(N);  // Coefficients combinatoires
    std::vector<double> V2(N);  // Sommes cumulées de V1
    double coef = 1.0;          // Initialisation du coefficient combinatoire
    double up = N;              // Numérateur initial
    double dw = 1.0;            // Dénominateur initial
    double su = 0.0;            // Somme cumulative pour V2

    for (int k = 0; k < N; ++k) {
        coef *= up;  // Produit des termes décroissants du numérateur
        coef /= dw;  // Division par le dénominateur croissant
        --up;        // Mise à jour du numérateur
        ++dw;        // Mise à jour du dénominateur
        V1[k] = coef; // Stocke le coefficient
        su += coef;   // Somme cumulée
    }

    for (int k = 0; k < N; ++k) {
        V2[k] = su;   // Stocke la somme cumulée pour V2
        su -= V1[k];  // Mise à jour de la somme
    }

    // Étape 5 : Préchargement des puissances pour k = N+1 à 2N
    std::vector<std::complex<double>> powers_k_c1_ext(2 * N - N); // Extension k^(-c1)
    for (int k = N + 1; k <= 2 * N; ++k) {
        powers_k_c1_ext[k - N - 1] = un / pow(static_cast<double>(k), c1);
    }

    // Étape 6 : Calcul de sum2 en utilisant les préchargements
    for (int k = N + 1; k <= 2 * N; ++k) {
        std::complex<double> p2 = powers_k_c1_ext[k - N - 1]; // Valeur préchargée
        double ek = V2[k - N - 1];                           // Coefficient combinatoire
        std::complex<double> c3(ek, 0.0);                    // Conversion en complexe
        std::complex<double> c4 = p2 * c3;                   // Produit des termes
        if (k % 2 == 0) {
            sum2 += c4; // Ajout si pair
        } else {
            sum2 -= c4; // Soustraction si impair
        }
    }

    // Étape 7 : Calcul final du résultat
    std::complex<double> rez = (sum1 + sum2 / pow(deux, N)) * p1;

    // Étape 8 : Retourne le résultat
    return rez;
}


void test_one_zero(double t)
{
	double RS=Z(t,4);
	std::complex <double> c1=test_zerod(t,10);
	std::complex <double> c2=test_zerod(t,100);
	std::complex <double> c3=test_zerod(t,1000);
	std::cout << std::setprecision(15);
	std::cout << "RS= "<<" "<<RS<<" TEST10= "<< c1 << " TEST100=" << c2 << " TEST1000=" << c3 << std::endl;
	
}

void tests_zeros()
{
	test_one_zero(14.1347251417346937904572519835625);
	test_one_zero(101.3178510057313912287854479402924);
	test_one_zero(1001.3494826377827371221033096531063);
	test_one_zero(10000.0653454145353147502287213889928);

}

/*
	An option to better the performance of Z(t) for large values of t is to simplify the equations
	to validate we present a function that tests the known zeros :  look at https://www.lmfdb.org/zeros/zeta/?limit=10&N=10
	We should obtain 0.0
        no need to test many zeros. In case of a bug the column 2 will show large values instead of values close to 0 like with the original code
	Observe that when t increases the accuracy increases until the limits of the IEEE 754 norm block us, we should work with extended precision
	But here a few digits of precision are enough to count the zeros, only on rare cases the _float128 should be used
	But this limitation only appears very far and with the constraint of resources it won't be possible to reach this region. 
	----------------------------------------------------------------------------------------------------------------------
	value in double			should be 0.0		 value in strings: LMFDB all the digits are corrects
        14.13472514173469463117        -0.00000248590756340983   14.1347251417346937904572519835625
        21.02203963877155601381        -0.00000294582959536882   21.0220396387715549926284795938969
        25.01085758014568938279        -0.00000174024500421144   25.0108575801456887632137909925628
       178.37740777609997167019         0.00000000389177887139   178.3774077760999772858309354141843
       179.91648402025700193008         0.00000000315651035865   179.9164840202569961393400366120511
       182.20707848436646258961         0.00000000214091858131   182.207078484366461915407037226988
 371870901.89642333984375000000         0.00000060389888876036   371870901.8964233245801283081720385309201
 371870902.28132432699203491211        -0.00000083698274928878   371870902.2813243157291041227177012243450
 371870902.52132433652877807617        -0.00000046459056067712   371870902.5213243412580878836297930128983
*/

/*
char line[1024];
void test_fileof_zeros(const char *fname)
{
	FILE *fi=fopen(fname,"r");
	assert(fi!=NULL);
	for(;;){
		double t,RS;
		fgets(line,1000,fi);
		if(feof(fi))break;
		sscanf(line,"%lf",&t);
		RS=Z(t,4);
		printf(" %30.20lf %30.20lf   %s",t,RS,line);

	}
	fclose(fi);
}

*/

/*

Explications des Modifications
Pré-chargement des valeurs de zout et prev :

on a optimisé la boucle principale en assurant que zout est calculé avant la comparaison avec prev. Cela réduit le nombre de calculs nécessaires 
dans chaque itération de la boucle.
Pré-chargement des données Z(t, 4) :

L'appel à la fonction Z(t, 4) est déplacé dans la boucle pour éviter de recalculer des données déjà traitées ou pré-calculées. La valeur de zout est 
calculée à chaque itération de la boucle, mais son accès est fait une seule fois à l'intérieur de la boucle, ce qui évite des accès mémoire répétés.
Utilisation d'une seule variable pour les intervalles (prev et zout) :

prev et zout sont utilisés pour la comparaison et sont donc mis à jour immédiatement après chaque itération. Cela améliore la cache locality, 
c'est-à-dire l'efficacité du cache en mémoire.
Pré-chargement du calcul STEP et de NUMSAMPLES :

Ces valeurs sont calculées une fois au début et utilisées dans la boucle pour déterminer les pas (STEP) et le nombre total d'échantillons 
(NUMSAMPLES). Cela évite de recalculer ces valeurs à chaque itération de la boucle.
Réduction des calculs répétitifs :

Les calculs dans la boucle sont réduits à leur minimum nécessaire. Par exemple, le calcul de STEP et NUMSAMPLES n'est effectué qu'une 
seule fois avant la boucle, et la comparaison zout < 0 ou zout > 0 est faite de manière optimale.
Amélioration des performances avec des caches modernes :

En évitant de recalculer des termes à chaque itération, la technique de pré-chargement améliore la localité de référence. 
Cela signifie que les données nécessaires sont chargées dans les caches du processeur avant leur utilisation, ce qui améliore l'accès aux données et réduit la latence.


*/

int main(int argc, char **argv) {
    double LOWER, UPPER, SAMP;
    const double pi = 3.1415926535897932385;

    // Tests (commentés)
    //tests_zeros();
    //test_fileof_zeros("ZEROS");

    try {
        LOWER = std::atof(argv[1]);
        UPPER = std::atof(argv[2]);
        SAMP = std::atof(argv[3]);
    }
    catch (...) {
        std::cout << argv[0] << " START END SAMPLING" << std::endl;
        return -1;
    }

    // Estimation du nombre de zéros (avant d'entrer dans la boucle)
    double estimate_zeros = theta(UPPER) / pi;
    printf("I estimate I will find %1.3lf zeros\n", estimate_zeros);

    double STEP = 1.0 / SAMP;
    ui64 NUMSAMPLES = floor((UPPER - LOWER) * SAMP + 1.0);
    double prev = 0.0;
    double count = 0.0;

    double t1 = dml_micros();

    // Pré-chargement des informations nécessaires
    // Ici, on calcule les intervalles et estimons la trajectoire des résultats
    // Cela permet de réduire les appels répétitifs aux calculs en boucle
    double zout = 0.0;
    
    // Boucle principale optimisée
    for (double t = LOWER; t <= UPPER; t += STEP) {
        // Pré-chargement des données relatives à Z(t, 4)
        zout = Z(t, 4); // Calcul du zéro pour chaque valeur de t
        
        // Pré-chargement de la valeur précédente pour la comparaison
        if (t > LOWER) {
            // Comparaison de zout avec prev (pré-chargé)
            if (((zout < 0.0) && (prev > 0.0)) || ((zout > 0.0) && (prev < 0.0))) {
                count++;  // Incrémentation du compteur de zéros
            }
        }

        // Pré-chargement de prev pour la prochaine itération
        prev = zout;
    }

    double t2 = dml_micros();

    // Affichage du nombre de zéros trouvés
    printf("I found %1.0lf Zeros in %.3lf seconds\n", count, (t2 - t1) / 1000000.0);
    return 0;
}




